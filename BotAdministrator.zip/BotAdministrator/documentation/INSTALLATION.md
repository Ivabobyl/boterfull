# Инструкция по установке бота BudgetBuddy

## Требования

- Python 3.9 или выше
- PostgreSQL 13 или выше
- Доступ к Telegram Bot API (токен бота)

## Установка на Windows

1. **Установите Python**:
   - Загрузите и установите Python с [официального сайта](https://www.python.org/downloads/windows/)
   - При установке отметьте галочку "Add Python to PATH"

2. **Установите PostgreSQL**:
   - Загрузите и установите PostgreSQL с [официального сайта](https://www.postgresql.org/download/windows/)
   - Запомните пароль пользователя postgres, он понадобится позже

3. **Клонируйте или распакуйте архив с проектом**:
   ```
   git clone <url-репозитория> budgetbuddy
   cd budgetbuddy
   ```
   или распакуйте архив в директорию проекта

4. **Создайте виртуальное окружение и установите зависимости**:
   ```
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```

5. **Создайте базу данных в PostgreSQL**:
   - Запустите pgAdmin или psql
   - Создайте новую базу данных для бота:
   ```sql
   CREATE DATABASE budgetbuddy;
   ```

6. **Настройте переменные окружения**:
   - Создайте файл `.env` в корне проекта со следующим содержимым:
   ```
   TELEGRAM_BOT_TOKEN=ваш_токен_бота
   DATABASE_URL=postgresql://username:password@localhost:5432/budgetbuddy
   ```
   Замените `username`, `password` и `budgetbuddy` на ваши данные

7. **Запустите бота**:
   ```
   python bot.py
   ```
   
   Для запуска через консоль без дополнительного окна можно использовать файл `start.bat`

## Установка на Ubuntu

1. **Установите Python и необходимые пакеты**:
   ```bash
   sudo apt update
   sudo apt install -y python3 python3-pip python3-venv postgresql postgresql-contrib
   ```

2. **Настройте PostgreSQL**:
   ```bash
   sudo -u postgres psql -c "CREATE DATABASE budgetbuddy;"
   sudo -u postgres psql -c "CREATE USER botuser WITH PASSWORD 'password';"
   sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE budgetbuddy TO botuser;"
   ```

3. **Клонируйте или распакуйте архив с проектом**:
   ```bash
   git clone <url-репозитория> budgetbuddy
   cd budgetbuddy
   ```
   или распакуйте архив в директорию проекта

4. **Создайте виртуальное окружение и установите зависимости**:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

5. **Настройте переменные окружения**:
   - Создайте файл `.env` в корне проекта:
   ```bash
   echo "TELEGRAM_BOT_TOKEN=ваш_токен_бота" > .env
   echo "DATABASE_URL=postgresql://botuser:password@localhost:5432/budgetbuddy" >> .env
   ```
   
   Или отредактируйте конфигурацию в `config.py`

6. **Запустите бота**:
   ```bash
   python3 bot.py
   ```
   
   Для запуска в фоновом режиме:
   ```bash
   nohup python3 bot.py &
   ```
   
   Или используйте скрипт `start.sh` с правами на выполнение:
   ```bash
   chmod +x start.sh
   ./start.sh
   ```

## Запуск как системный сервис на Ubuntu

Для автоматического запуска бота при перезагрузке сервера, создайте и настройте системный сервис:

1. **Создайте файл сервиса**:
   ```bash
   sudo nano /etc/systemd/system/budgetbuddy.service
   ```

2. **Добавьте следующий конфиг** (измените пути согласно вашей установке):
   ```
   [Unit]
   Description=BudgetBuddy Telegram Bot
   After=network.target postgresql.service

   [Service]
   User=your_username
   WorkingDirectory=/path/to/budgetbuddy
   ExecStart=/path/to/budgetbuddy/venv/bin/python /path/to/budgetbuddy/bot.py
   Restart=always
   RestartSec=10
   StandardOutput=syslog
   StandardError=syslog
   SyslogIdentifier=budgetbuddy

   [Install]
   WantedBy=multi-user.target
   ```

3. **Включите и запустите сервис**:
   ```bash
   sudo systemctl enable budgetbuddy.service
   sudo systemctl start budgetbuddy.service
   ```

4. **Проверьте статус**:
   ```bash
   sudo systemctl status budgetbuddy.service
   ```

## Дополнительные настройки

### Файлы конфигурации

- **config.py**: Основные настройки бота и системы (токен, роли, курсы по умолчанию)
- **.env**: Рекомендуется хранить секреты в этом файле (не включать в систему контроля версий)

### Изменение настроек реферальной системы

Для изменения процентов вознаграждения отредактируйте константу `REFERRAL_TIERS` в файле `config.py`:

```python
REFERRAL_TIERS = {
    0: 0.10,   # 0-10 рефералов: 10%
    10: 0.125, # 10-25 рефералов: 12.5%
    25: 0.15,  # 25-50 рефералов: 15%
    50: 0.175, # 50-100 рефералов: 17.5%
    100: 0.20  # 100+ рефералов: 20%
}
```