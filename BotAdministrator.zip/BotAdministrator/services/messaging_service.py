from models import Session, User, CustomCommand
from config import UserRole, logger
from telegram import Bot, ParseMode

def send_message_to_user(bot, user_id, text, parse_mode=ParseMode.MARKDOWN, **kwargs):
    """Send a message to a specific user"""
    try:
        return bot.send_message(
            chat_id=user_id,
            text=text,
            parse_mode=parse_mode,
            **kwargs
        )
    except Exception as e:
        logger.error(f"Error sending message to user {user_id}: {e}")
        return None

def send_broadcast(bot, text, target_role=None, is_active=True, parse_mode=ParseMode.MARKDOWN, **kwargs):
    """Send a broadcast message to multiple users"""
    session = Session()
    try:
        # Query users
        query = session.query(User)
        
        if target_role:
            if isinstance(target_role, str):
                target_role = UserRole[target_role.upper()]
            query = query.filter(User.role == target_role)
        
        if is_active is not None:
            query = query.filter(User.is_active == is_active)
        
        users = query.all()
        
        results = {
            "total": len(users),
            "successful": 0,
            "failed": 0,
            "failures": []
        }
        
        # Send the message to each user
        for user in users:
            try:
                bot.send_message(
                    chat_id=user.telegram_id,
                    text=text,
                    parse_mode=parse_mode,
                    **kwargs
                )
                results["successful"] += 1
            except Exception as e:
                logger.error(f"Error sending broadcast to user {user.telegram_id}: {e}")
                results["failed"] += 1
                results["failures"].append({
                    "user_id": user.telegram_id,
                    "error": str(e)
                })
        
        return results
    finally:
        session.close()

def get_custom_command(command_name):
    """Get a custom command by name"""
    session = Session()
    try:
        return session.query(CustomCommand).filter(
            CustomCommand.command == command_name,
            CustomCommand.is_active == True
        ).first()
    finally:
        session.close()

def add_custom_command(command_name, response_text, created_by=None):
    """Add a new custom command"""
    session = Session()
    try:
        # Check if command already exists
        existing = session.query(CustomCommand).filter(
            CustomCommand.command == command_name
        ).first()
        
        if existing:
            return {"error": "command_exists", "command": existing}
        
        # Create the command
        cmd = CustomCommand(
            command=command_name,
            response_text=response_text,
            created_by=created_by
        )
        session.add(cmd)
        session.commit()
        
        return cmd
    finally:
        session.close()

def update_custom_command(command_name, response_text=None, is_active=None):
    """Update an existing custom command"""
    session = Session()
    try:
        cmd = session.query(CustomCommand).filter(
            CustomCommand.command == command_name
        ).first()
        
        if not cmd:
            return None
        
        if response_text is not None:
            cmd.response_text = response_text
        
        if is_active is not None:
            cmd.is_active = is_active
        
        session.commit()
        return cmd
    finally:
        session.close()

def delete_custom_command(command_name):
    """Delete a custom command"""
    session = Session()
    try:
        cmd = session.query(CustomCommand).filter(
            CustomCommand.command == command_name
        ).first()
        
        if not cmd:
            return False
        
        session.delete(cmd)
        session.commit()
        return True
    finally:
        session.close()

def get_all_custom_commands(include_inactive=False):
    """Get all custom commands"""
    session = Session()
    try:
        query = session.query(CustomCommand)
        
        if not include_inactive:
            query = query.filter(CustomCommand.is_active == True)
        
        return query.order_by(CustomCommand.command).all()
    finally:
        session.close()
