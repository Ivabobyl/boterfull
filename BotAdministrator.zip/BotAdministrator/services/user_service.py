from models import Session, User, Order, ReferralBonus
from config import UserRole
from sqlalchemy import func
import uuid

def get_user_by_telegram_id(telegram_id):
    """Get a user by their Telegram ID"""
    session = Session()
    try:
        return session.query(User).filter(User.telegram_id == telegram_id).first()
    finally:
        session.close()

def create_user(telegram_id, username=None, first_name=None, last_name=None):
    """Create a new user"""
    session = Session()
    try:
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            referral_code=str(uuid.uuid4())[:8]
        )
        session.add(user)
        session.commit()
        return user
    finally:
        session.close()

def update_user(telegram_id, **kwargs):
    """Update user information"""
    session = Session()
    try:
        user = session.query(User).filter(User.telegram_id == telegram_id).first()
        if not user:
            return None
        
        for key, value in kwargs.items():
            if hasattr(user, key):
                setattr(user, key, value)
        
        session.commit()
        return user
    finally:
        session.close()

def set_user_role(telegram_id, role):
    """Set a user's role"""
    if isinstance(role, str):
        role = UserRole[role.upper()]
    
    return update_user(telegram_id, role=role)

def set_user_active(telegram_id, is_active):
    """Set a user's active status"""
    return update_user(telegram_id, is_active=is_active)

def process_referral(user_id, referral_code):
    """Process a referral code for a user"""
    session = Session()
    try:
        user = session.query(User).filter(User.id == user_id).first()
        if not user or user.referred_by:
            return False
        
        referrer = session.query(User).filter(User.referral_code == referral_code).first()
        if not referrer or referrer.id == user.id:
            return False
        
        user.referred_by = referrer.id
        session.commit()
        return True
    finally:
        session.close()

def change_user_balance(telegram_id, amount):
    """Change a user's balance"""
    session = Session()
    try:
        user = session.query(User).filter(User.telegram_id == telegram_id).first()
        if not user:
            return None
        
        old_balance = user.balance
        user.balance += amount
        
        # Make sure balance is not negative
        if user.balance < 0:
            user.balance = 0
        
        session.commit()
        return {
            "user": user,
            "old_balance": old_balance,
            "new_balance": user.balance,
            "change": amount
        }
    finally:
        session.close()

def get_all_users(page=1, per_page=10, role=None, is_active=None):
    """Get all users with pagination"""
    session = Session()
    try:
        query = session.query(User)
        
        if role is not None:
            query = query.filter(User.role == role)
        
        if is_active is not None:
            query = query.filter(User.is_active == is_active)
        
        total = query.count()
        
        users = query.order_by(User.created_at.desc()).offset((page-1)*per_page).limit(per_page).all()
        
        return {
            "users": users,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    finally:
        session.close()

def get_user_stats(telegram_id):
    """Get statistics for a user"""
    session = Session()
    try:
        user = session.query(User).filter(User.telegram_id == telegram_id).first()
        if not user:
            return None
        
        # Count orders by status
        total_orders = session.query(Order).filter(Order.user_id == user.id).count()
        completed_orders = session.query(Order).filter(
            Order.user_id == user.id, 
            Order.status == "completed"
        ).count()
        pending_orders = session.query(Order).filter(
            Order.user_id == user.id, 
            Order.status.in_(["pending", "in_progress"])
        ).count()
        
        # Calculate total volume
        total_volume = session.query(func.sum(Order.amount_rub)).filter(
            Order.user_id == user.id,
            Order.status == "completed"
        ).scalar() or 0
        
        # Count referrals
        referral_count = user.get_referral_count(session)
        
        # Calculate total referral earnings
        total_referral_earnings = session.query(func.sum(ReferralBonus.amount)).filter(
            ReferralBonus.user_id == user.id
        ).scalar() or 0
        
        # Get referral percentage based on count
        from utils.helpers import get_referral_percentage
        referral_percentage = get_referral_percentage(session, user.id)
        
        return {
            "user": user,
            "total_orders": total_orders,
            "completed_orders": completed_orders,
            "pending_orders": pending_orders,
            "total_volume": total_volume,
            "referral_count": referral_count,
            "total_referral_earnings": total_referral_earnings,
            "referral_percentage": referral_percentage
        }
    finally:
        session.close()
