from models import Session, User, ReferralBonus, Order
from config import REFERRAL_TIERS
from sqlalchemy import func

def get_referral_percentage(user_id):
    """Get the referral percentage based on the number of referrals"""
    session = Session()
    try:
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            return 0
        
        # Count referrals
        referral_count = user.get_referral_count(session)
        
        # Determine the tier
        tier_percentage = 0
        for tier, percentage in sorted(REFERRAL_TIERS.items()):
            if referral_count >= tier:
                tier_percentage = percentage
            else:
                break
        
        return tier_percentage
    finally:
        session.close()

def process_referral_bonus(order_id):
    """Process the referral bonus for an order"""
    session = Session()
    try:
        order = session.query(Order).filter(Order.id == order_id).first()
        if not order or not order.spread:
            return False
        
        # Get the user who made the order
        user = order.user
        
        # Check if the user was referred by someone
        if not user.referred_by:
            return False
        
        # Get the referrer
        referrer = session.query(User).filter(User.id == user.referred_by).first()
        if not referrer:
            return False
        
        # Calculate the bonus
        referral_percentage = get_referral_percentage(referrer.id)
        bonus_amount = order.spread * referral_percentage
        
        # Create the bonus record
        bonus = ReferralBonus(
            user_id=referrer.id,
            referral_id=user.id,
            order_id=order.id,
            amount=bonus_amount,
            percentage=referral_percentage
        )
        session.add(bonus)
        
        # Add the bonus to the referrer's balance
        referrer.balance += bonus_amount
        
        session.commit()
        return {
            "referrer": referrer,
            "bonus_amount": bonus_amount,
            "percentage": referral_percentage
        }
    finally:
        session.close()

def get_user_referrals(user_id, page=1, per_page=10):
    """Get referrals for a user with pagination"""
    session = Session()
    try:
        query = session.query(User).filter(User.referred_by == user_id)
        
        total = query.count()
        
        referrals = query.order_by(User.created_at.desc()).offset((page-1)*per_page).limit(per_page).all()
        
        return {
            "referrals": referrals,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    finally:
        session.close()

def get_user_bonuses(user_id, page=1, per_page=10):
    """Get referral bonuses for a user with pagination"""
    session = Session()
    try:
        query = session.query(ReferralBonus).filter(ReferralBonus.user_id == user_id)
        
        total = query.count()
        
        bonuses = query.order_by(ReferralBonus.created_at.desc()).offset((page-1)*per_page).limit(per_page).all()
        
        # Enhance bonuses with referral information
        enhanced_bonuses = []
        for bonus in bonuses:
            referral = session.query(User).filter(User.id == bonus.referral_id).first()
            order = session.query(Order).filter(Order.id == bonus.order_id).first()
            
            enhanced_bonuses.append({
                "bonus": bonus,
                "referral": referral,
                "order": order
            })
        
        return {
            "bonuses": enhanced_bonuses,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    finally:
        session.close()

def get_referral_statistics(user_id):
    """Get detailed referral statistics for a user"""
    session = Session()
    try:
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            return None
        
        # Count referrals
        referral_count = user.get_referral_count(session)
        
        # Calculate total earnings
        total_earnings = session.query(func.sum(ReferralBonus.amount)).filter(
            ReferralBonus.user_id == user_id
        ).scalar() or 0
        
        # Get referral percentage
        referral_percentage = get_referral_percentage(user_id)
        
        # Calculate next tier
        next_tier = None
        next_tier_count = None
        current_tier = 0
        
        for tier, percentage in sorted(REFERRAL_TIERS.items()):
            if referral_count < tier:
                next_tier = percentage
                next_tier_count = tier
                break
            current_tier = tier
        
        next_tier_info = {
            "current_tier": current_tier,
            "current_percentage": referral_percentage,
            "next_tier": next_tier,
            "next_tier_count": next_tier_count,
            "referrals_to_next_tier": next_tier_count - referral_count if next_tier_count else None
        }
        
        # Get recent bonuses
        recent_bonuses = session.query(ReferralBonus).filter(
            ReferralBonus.user_id == user_id
        ).order_by(ReferralBonus.created_at.desc()).limit(5).all()
        
        # Enhance bonuses with referral information
        enhanced_bonuses = []
        for bonus in recent_bonuses:
            referral = session.query(User).filter(User.id == bonus.referral_id).first()
            order = session.query(Order).filter(Order.id == bonus.order_id).first()
            
            enhanced_bonuses.append({
                "bonus": bonus,
                "referral": referral,
                "order": order
            })
        
        return {
            "user": user,
            "referral_count": referral_count,
            "total_earnings": total_earnings,
            "current_percentage": referral_percentage * 100,  # As percentage
            "next_tier_info": next_tier_info,
            "recent_bonuses": enhanced_bonuses
        }
    finally:
        session.close()
