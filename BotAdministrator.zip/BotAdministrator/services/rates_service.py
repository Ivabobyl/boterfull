from models import Session, Rate
from config import DEFAULT_RATES
import datetime

def get_current_rates():
    """Get the current exchange rates"""
    session = Session()
    try:
        latest_rate = session.query(Rate).order_by(Rate.updated_at.desc()).first()
        
        # В соответствии с ТЗ, только админ может установить курсы
        # Не создаем курсы автоматически, возвращаем None если их нет
        if not latest_rate:
            return None
        
        return {
            "ltc_usd_buy": latest_rate.ltc_usd_buy,
            "ltc_usd_sell": latest_rate.ltc_usd_sell,
            "usd_rub_buy": latest_rate.usd_rub_buy,
            "usd_rub_sell": latest_rate.usd_rub_sell,
            "updated_at": latest_rate.updated_at
        }
    finally:
        session.close()

def update_rates(ltc_usd_buy, ltc_usd_sell, usd_rub_buy, usd_rub_sell, updated_by=None):
    """Update the exchange rates"""
    session = Session()
    try:
        # Create new rate record
        new_rate = Rate(
            ltc_usd_buy=ltc_usd_buy,
            ltc_usd_sell=ltc_usd_sell,
            usd_rub_buy=usd_rub_buy,
            usd_rub_sell=usd_rub_sell,
            updated_by=updated_by
        )
        session.add(new_rate)
        session.commit()
        
        return new_rate
    finally:
        session.close()

def get_rate_history(page=1, per_page=10):
    """Get rate history with pagination"""
    session = Session()
    try:
        total = session.query(Rate).count()
        
        rates = session.query(Rate).order_by(Rate.updated_at.desc()).offset((page-1)*per_page).limit(per_page).all()
        
        return {
            "rates": rates,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    finally:
        session.close()

def calculate_ltc_to_rub(ltc_amount, is_buy=True):
    """Calculate RUB amount for a given LTC amount"""
    rates = get_current_rates()
    
    if is_buy:
        # How much USD we need to buy LTC
        usd_amount = ltc_amount * rates["ltc_usd_buy"]
        # How much RUB we need to buy USD
        rub_amount = usd_amount * rates["usd_rub_buy"]
    else:  # sell
        # How much USD we get for LTC
        usd_amount = ltc_amount * rates["ltc_usd_sell"]
        # How much RUB we get for USD
        rub_amount = usd_amount * rates["usd_rub_sell"]
    
    return rub_amount

def calculate_rub_to_ltc(rub_amount, is_buy=True):
    """Calculate LTC amount for a given RUB amount"""
    rates = get_current_rates()
    
    if is_buy:
        # How much USD we get for RUB
        usd_amount = rub_amount / rates["usd_rub_buy"]
        # How much LTC we get for USD
        ltc_amount = usd_amount / rates["ltc_usd_buy"]
    else:  # sell
        # How much USD we get for RUB
        usd_amount = rub_amount / rates["usd_rub_sell"]
        # How much LTC we need to sell to get USD
        ltc_amount = usd_amount / rates["ltc_usd_sell"]
    
    return ltc_amount
