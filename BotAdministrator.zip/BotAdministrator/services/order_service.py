from models import Session, User, Order
from config import OrderType, OrderStatus
from utils.helpers import calculate_ltc_amount, calculate_spread, process_referral_bonus
import datetime
import uuid

def create_order(user_id, order_type, amount_rub, rates=None):
    """Create a new order"""
    session = Session()
    try:
        # Get the user
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            return None
        
        # Calculate LTC amount based on rates
        amount_ltc = calculate_ltc_amount(session, amount_rub, order_type)
        
        # Get rates if not provided
        if not rates:
            from utils.helpers import get_current_rates
            rates = get_current_rates(session)
        
        # Create the order
        order = Order(
            user_id=user_id,
            type=OrderType.BUY if order_type.lower() == 'buy' else OrderType.SELL,
            amount_rub=amount_rub,
            amount_ltc=amount_ltc,
            rate_ltc_usd=rates['ltc_usd_buy' if order_type.lower() == 'buy' else 'ltc_usd_sell'],
            rate_usd_rub=rates['usd_rub_buy' if order_type.lower() == 'buy' else 'usd_rub_sell']
        )
        
        session.add(order)
        session.commit()
        
        return order
    finally:
        session.close()

def get_order_by_id(order_id):
    """Get an order by ID"""
    session = Session()
    try:
        return session.query(Order).filter(Order.id == order_id).first()
    finally:
        session.close()

def get_order_by_number(order_number):
    """Get an order by number"""
    session = Session()
    try:
        return session.query(Order).filter(Order.order_number == order_number).first()
    finally:
        session.close()

def get_active_orders(page=1, per_page=10):
    """Get active orders with pagination"""
    session = Session()
    try:
        query = session.query(Order).filter(
            Order.status.in_([OrderStatus.PENDING, OrderStatus.IN_PROGRESS])
        )
        
        total = query.count()
        
        orders = query.order_by(Order.created_at.asc()).offset((page-1)*per_page).limit(per_page).all()
        
        return {
            "orders": orders,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    finally:
        session.close()

def get_user_orders(user_id, page=1, per_page=10, status=None):
    """Get orders for a specific user with pagination"""
    session = Session()
    try:
        query = session.query(Order).filter(Order.user_id == user_id)
        
        if status:
            if isinstance(status, list):
                query = query.filter(Order.status.in_(status))
            else:
                query = query.filter(Order.status == status)
        
        total = query.count()
        
        orders = query.order_by(Order.created_at.desc()).offset((page-1)*per_page).limit(per_page).all()
        
        return {
            "orders": orders,
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page
        }
    finally:
        session.close()

def take_order(order_id, operator_id):
    """Take an order (assign to operator)"""
    session = Session()
    try:
        order = session.query(Order).filter(Order.id == order_id).first()
        if not order:
            return None
        
        # Check if order is already in progress
        if order.status == OrderStatus.IN_PROGRESS:
            return {"error": "already_in_progress", "order": order}
        
        # Check if order is completed or cancelled
        if order.status in [OrderStatus.COMPLETED, OrderStatus.CANCELLED]:
            return {"error": "already_completed", "order": order}
        
        # Update order status and assign operator
        order.status = OrderStatus.IN_PROGRESS
        order.operator_id = operator_id
        session.commit()
        
        return order
    finally:
        session.close()

def complete_order(order_id):
    """Complete an order"""
    session = Session()
    try:
        order = session.query(Order).filter(Order.id == order_id).first()
        if not order:
            return None
        
        # Check if order is already completed or cancelled
        if order.status in [OrderStatus.COMPLETED, OrderStatus.CANCELLED]:
            return {"error": "already_completed", "order": order}
        
        # Update order status
        order.status = OrderStatus.COMPLETED
        order.completed_at = datetime.datetime.utcnow()
        
        # Calculate and save spread
        order.spread = calculate_spread(session, order.id)
        
        session.commit()
        
        # Process referral bonus
        process_referral_bonus(session, order.id)
        
        return order
    finally:
        session.close()

def cancel_order(order_id):
    """Cancel an order"""
    session = Session()
    try:
        order = session.query(Order).filter(Order.id == order_id).first()
        if not order:
            return None
        
        # Check if order is already completed or cancelled
        if order.status in [OrderStatus.COMPLETED, OrderStatus.CANCELLED]:
            return {"error": "already_completed", "order": order}
        
        # Update order status
        order.status = OrderStatus.CANCELLED
        session.commit()
        
        return order
    finally:
        session.close()

def get_order_details(order_id, include_spread=False):
    """Get detailed information about an order"""
    session = Session()
    try:
        order = session.query(Order).filter(Order.id == order_id).first()
        if not order:
            return None
        
        # Get the user
        user = session.query(User).filter(User.id == order.user_id).first()
        
        # Get the operator if assigned
        operator = None
        if order.operator_id:
            operator = session.query(User).filter(User.id == order.operator_id).first()
        
        # Calculate potential spread
        spread = order.spread
        if not spread and include_spread:
            spread = calculate_spread(session, order.id)
        
        return {
            "order": order,
            "user": user,
            "operator": operator,
            "spread": spread if include_spread else None
        }
    finally:
        session.close()
