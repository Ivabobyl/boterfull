from telegram import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup

# Main menu keyboards
def get_main_menu_keyboard(is_operator=False, is_admin=False):
    """Get the main menu keyboard based on user role"""
    keyboard = [
        [KeyboardButton("💵 Купить LTC"), KeyboardButton("💰 Продать LTC")],
        [KeyboardButton("📊 Курсы"), KeyboardButton("👤 Профиль")],
        [KeyboardButton("📚 Мои заявки"), KeyboardButton("👥 Реферальная программа")]
    ]
    
    if is_operator or is_admin:
        keyboard.append([KeyboardButton("📋 Активные заявки")])
    
    if is_admin:
        keyboard.append([KeyboardButton("⚙️ Админ-панель")])
        
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# Admin menu keyboard
def get_admin_menu_keyboard():
    """Get the admin menu keyboard"""
    keyboard = [
        [KeyboardButton("📝 Установить курсы"), KeyboardButton("👥 Управление пользователями")],
        [KeyboardButton("📊 Статистика"), KeyboardButton("📨 Создать рассылку")],
        [KeyboardButton("🔄 Управление командами"), KeyboardButton("🔙 Назад")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# Order action keyboards
def get_order_action_keyboard(order_id, operator=False, admin=False):
    """Get keyboard for order actions based on user role"""
    keyboard = []
    
    # Для новых заявок показываем кнопки "Взять в работу" и "Отклонить"
    if operator or admin:
        keyboard.append([
            InlineKeyboardButton("✅ Взять в работу", callback_data=f"take_order_{order_id}")
        ])
    
    keyboard.append([
        InlineKeyboardButton("❌ Отклонить", callback_data=f"cancel_order_{order_id}")
    ])
    
    # Кнопка "Завершить" показывается только для заявок в работе
    if operator or admin:
        keyboard.append([
            InlineKeyboardButton("✅ Завершить", callback_data=f"complete_order_{order_id}")
        ])
    
    return InlineKeyboardMarkup(keyboard)
    
def get_new_order_keyboard(order_id):
    """Клавиатура для новых заявок в общем чате операторов"""
    keyboard = [
        [
            InlineKeyboardButton("✅ Взять в работу", callback_data=f"take_order_{order_id}"),
            InlineKeyboardButton("❌ Отклонить", callback_data=f"cancel_order_{order_id}")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

# Back button keyboard
def get_back_keyboard(callback_data="back"):
    """Get a keyboard with just a back button"""
    keyboard = [[InlineKeyboardButton("🔙 Назад", callback_data=callback_data)]]
    return InlineKeyboardMarkup(keyboard)

# Confirmation keyboard
def get_confirmation_keyboard(action, item_id):
    """Get a confirmation keyboard for various actions"""
    keyboard = [
        [
            InlineKeyboardButton("✅ Да", callback_data=f"confirm_{action}_{item_id}"),
            InlineKeyboardButton("❌ Нет", callback_data=f"cancel_{action}_{item_id}")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

# User management keyboard
def get_user_management_keyboard(user_id):
    """Get the keyboard for user management"""
    keyboard = [
        [
            InlineKeyboardButton("🛡️ Сделать оператором", callback_data=f"make_operator_{user_id}"),
            InlineKeyboardButton("👑 Сделать админом", callback_data=f"make_admin_{user_id}")
        ],
        [
            InlineKeyboardButton("🔄 Сделать пользователем", callback_data=f"make_user_{user_id}")
        ],
        [
            InlineKeyboardButton("🚫 Заблокировать", callback_data=f"block_user_{user_id}"),
            InlineKeyboardButton("✅ Разблокировать", callback_data=f"unblock_user_{user_id}")
        ],
        [
            InlineKeyboardButton("💰 Изменить баланс", callback_data=f"change_balance_{user_id}")
        ],
        [
            InlineKeyboardButton("🔙 Назад", callback_data="back_to_users")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)

# Pagination keyboard
def get_pagination_keyboard(page, total_pages, callback_prefix):
    """Get a pagination keyboard"""
    keyboard = []
    row = []
    
    if page > 1:
        row.append(InlineKeyboardButton("⬅️", callback_data=f"{callback_prefix}_{page-1}"))
    
    row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="dummy"))
    
    if page < total_pages:
        row.append(InlineKeyboardButton("➡️", callback_data=f"{callback_prefix}_{page+1}"))
    
    keyboard.append(row)
    return InlineKeyboardMarkup(keyboard)

# Referral keyboard
def get_referral_keyboard(referral_code):
    """Get the keyboard for referral program"""
    keyboard = [
        [
            InlineKeyboardButton(
                "🔗 Поделиться",
                switch_inline_query=f"Присоединяйтесь к обменнику криптовалюты LTC по моей реферальной ссылке! Код: {referral_code}"
            )
        ],
        [
            InlineKeyboardButton("📊 Моя статистика", callback_data="referral_stats")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)
