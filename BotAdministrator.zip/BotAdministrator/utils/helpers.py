import datetime
from sqlalchemy.orm import Session
from models import User, Order, Rate, ReferralBonus
from config import REFERRAL_TIERS, DEFAULT_RATES, logger

def get_user_by_telegram_id(session: Session, telegram_id) -> User:
    """Get a user by their Telegram ID"""
    # Преобразуем telegram_id в строку для поиска в базе данных
    telegram_id_str = str(telegram_id)
    return session.query(User).filter(User.telegram_id == telegram_id_str).first()

def get_user_role(session: Session, telegram_id) -> str:
    """Get the role of a user by their Telegram ID"""
    user = get_user_by_telegram_id(session, telegram_id)
    if user:
        return user.role.value
    return None

def is_admin(session: Session, telegram_id) -> bool:
    """Check if a user is an admin"""
    # Проверка на администратора в config.ADMIN_IDS
    from config import ADMIN_IDS
    if str(telegram_id) in ADMIN_IDS:
        user = get_user_by_telegram_id(session, telegram_id)
        if not user:
            # Создаем пользователя-админа, если его нет в базе
            from models import User, UserRole
            user = User(
                telegram_id=str(telegram_id),
                role=UserRole.ADMIN
            )
            session.add(user)
            session.commit()
        elif user.role.value != "admin":
            # Обновляем роль до админа
            from models import UserRole
            user.role = UserRole.ADMIN
            session.commit()
        return True
        
    # Проверяем по роли в базе данных
    user_role = get_user_role(session, telegram_id)
    return user_role == "admin"

def is_operator(session: Session, telegram_id) -> bool:
    """Check if a user is an operator"""
    user_role = get_user_role(session, telegram_id)
    return user_role == "operator" or user_role == "admin"

def get_current_rates(session: Session) -> dict:
    """Get the current cryptocurrency rates"""
    latest_rate = session.query(Rate).order_by(Rate.updated_at.desc()).first()
    
    if not latest_rate:
        # Create default rates if none exist
        new_rate = Rate(
            ltc_usd_buy=DEFAULT_RATES["ltc_usd_buy"],
            ltc_usd_sell=DEFAULT_RATES["ltc_usd_sell"],
            usd_rub_buy=DEFAULT_RATES["usd_rub_buy"],
            usd_rub_sell=DEFAULT_RATES["usd_rub_sell"]
        )
        session.add(new_rate)
        session.commit()
        latest_rate = new_rate
    
    return {
        "ltc_usd_buy": latest_rate.ltc_usd_buy,
        "ltc_usd_sell": latest_rate.ltc_usd_sell,
        "usd_rub_buy": latest_rate.usd_rub_buy,
        "usd_rub_sell": latest_rate.usd_rub_sell
    }

def calculate_ltc_amount(session: Session, amount_rub: float, order_type: str) -> float:
    """Calculate the LTC amount based on the RUB amount and order type"""
    rates = get_current_rates(session)
    
    if order_type == "buy":
        # How much USD we get for RUB
        usd_amount = amount_rub / rates["usd_rub_buy"]
        # How much LTC we get for USD
        ltc_amount = usd_amount / rates["ltc_usd_buy"]
    else:  # sell
        # How much USD we get for LTC
        usd_amount = amount_rub / rates["usd_rub_sell"]
        # How much LTC we sell to get the USD
        ltc_amount = usd_amount / rates["ltc_usd_sell"]
    
    return ltc_amount

def calculate_spread(session: Session, order_id: int) -> float:
    """Calculate the spread (profit) for an order"""
    order = session.query(Order).filter(Order.id == order_id).first()
    if not order:
        return 0
    
    rates = get_current_rates(session)
    
    if order.type.value == "buy":
        # Calculate what we pay for LTC vs what the user pays
        market_price_usd = order.amount_ltc * rates["ltc_usd_sell"]
        market_price_rub = market_price_usd * rates["usd_rub_sell"]
        spread = order.amount_rub - market_price_rub
    else:  # sell
        # Calculate what we get for LTC vs what we pay to the user
        market_price_usd = order.amount_ltc * rates["ltc_usd_buy"]
        market_price_rub = market_price_usd * rates["usd_rub_buy"]
        spread = market_price_rub - order.amount_rub
    
    return max(0, spread)

def get_referral_percentage(session: Session, user_id: int) -> float:
    """Get the referral percentage based on the number of referrals"""
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        return 0
    
    # Count referrals
    referral_count = user.get_referral_count(session)
    
    # Determine the tier
    tier_percentage = 0
    for tier, percentage in sorted(REFERRAL_TIERS.items()):
        if referral_count >= tier:
            tier_percentage = percentage
        else:
            break
    
    return tier_percentage

def process_referral_bonus(session: Session, order_id: int) -> bool:
    """Process the referral bonus for an order"""
    order = session.query(Order).filter(Order.id == order_id).first()
    if not order or not order.spread:
        return False
    
    # Get the user who made the order
    user = order.user
    
    # Check if the user was referred by someone
    if not user.referred_by:
        return False
    
    # Get the referrer
    referrer = session.query(User).filter(User.id == user.referred_by).first()
    if not referrer:
        return False
    
    # Calculate the bonus
    referral_percentage = get_referral_percentage(session, referrer.id)
    bonus_amount = order.spread * referral_percentage
    
    # Create the bonus record
    bonus = ReferralBonus(
        user_id=referrer.id,
        referral_id=user.id,
        order_id=order.id,
        amount=bonus_amount,
        percentage=referral_percentage
    )
    session.add(bonus)
    
    # Add the bonus to the referrer's balance
    referrer.balance += bonus_amount
    
    session.commit()
    return True

def format_currency(amount: float, currency: str = "RUB") -> str:
    """Format a currency amount with the currency symbol"""
    if currency == "RUB":
        return f"{amount:.2f} ₽"
    elif currency == "USD":
        return f"${amount:.2f}"
    elif currency == "LTC":
        return f"{amount:.8f} LTC"
    return f"{amount:.2f}"

def get_user_stats(session: Session, user_id: int) -> dict:
    """Get statistics for a user"""
    # Get the user
    user = session.query(User).filter(User.id == user_id).first()
    if not user:
        return {}
    
    # Count orders by status
    total_orders = session.query(Order).filter(Order.user_id == user_id).count()
    completed_orders = session.query(Order).filter(
        Order.user_id == user_id, 
        Order.status == "completed"
    ).count()
    pending_orders = session.query(Order).filter(
        Order.user_id == user_id, 
        Order.status.in_(["pending", "in_progress"])
    ).count()
    
    # Calculate total volume
    total_volume = session.query(Order).filter(
        Order.user_id == user_id,
        Order.status == "completed"
    ).with_entities(
        func.sum(Order.amount_rub)
    ).scalar() or 0
    
    # Count referrals
    referral_count = user.get_referral_count(session)
    
    # Calculate total referral earnings
    total_referral_earnings = session.query(ReferralBonus).filter(
        ReferralBonus.user_id == user_id
    ).with_entities(
        func.sum(ReferralBonus.amount)
    ).scalar() or 0
    
    return {
        "total_orders": total_orders,
        "completed_orders": completed_orders,
        "pending_orders": pending_orders,
        "total_volume": total_volume,
        "referral_count": referral_count,
        "total_referral_earnings": total_referral_earnings,
        "current_referral_percentage": get_referral_percentage(session, user_id) * 100
    }

def generate_order_summary(session: Session, order_id: int) -> str:
    """Generate a summary of an order"""
    order = session.query(Order).filter(Order.id == order_id).first()
    if not order:
        return "Заявка не найдена"
    
    user = order.user
    spread = order.spread if order.spread is not None else calculate_spread(session, order.id)
    operator = order.operator
    
    summary = f"✅ Заявка #{order.order_number} завершена!\n"
    summary += f"- Пользователь: @{user.username if user.username else 'Unknown'} | ID: {user.telegram_id}\n"
    
    if operator:
        summary += f"- Оператор: @{operator.username if operator.username else 'Unknown'}\n"
    
    summary += f"- Тип сделки: {'Покупка' if order.type.value == 'buy' else 'Продажа'} LTC\n"
    summary += f"- Сумма: {format_currency(order.amount_rub)}\n"
    summary += f"- Количество LTC: {format_currency(order.amount_ltc, 'LTC')}\n"
    
    if order.spread:
        summary += f"- Спред: +{format_currency(order.spread)}\n"
    
    return summary

from sqlalchemy import func

def get_admin_stats(session: Session) -> dict:
    """Get overall statistics for admins"""
    # Total users
    total_users = session.query(User).count()
    active_users = session.query(User).filter(User.is_active == True).count()
    
    # Total orders
    total_orders = session.query(Order).count()
    completed_orders = session.query(Order).filter(Order.status == "completed").count()
    pending_orders = session.query(Order).filter(Order.status == "pending").count()
    in_progress_orders = session.query(Order).filter(Order.status == "in_progress").count()
    
    # Total volume
    total_volume = session.query(func.sum(Order.amount_rub)).filter(
        Order.status == "completed"
    ).scalar() or 0
    
    # Total profit (spread)
    total_profit = session.query(func.sum(Order.spread)).filter(
        Order.status == "completed"
    ).scalar() or 0
    
    # Total referral payouts
    total_referral_payouts = session.query(func.sum(ReferralBonus.amount)).scalar() or 0
    
    # Top operators by completed orders
    top_operators = session.query(
        User.username, 
        func.count(Order.id).label('order_count')
    ).join(
        Order, 
        User.id == Order.operator_id
    ).filter(
        Order.status == "completed"
    ).group_by(
        User.username
    ).order_by(
        func.count(Order.id).desc()
    ).limit(5).all()
    
    # Top users by volume
    top_users = session.query(
        User.username, 
        func.sum(Order.amount_rub).label('volume')
    ).join(
        Order, 
        User.id == Order.user_id
    ).filter(
        Order.status == "completed"
    ).group_by(
        User.username
    ).order_by(
        func.sum(Order.amount_rub).desc()
    ).limit(5).all()
    
    return {
        "total_users": total_users,
        "active_users": active_users,
        "total_orders": total_orders,
        "completed_orders": completed_orders,
        "pending_orders": pending_orders,
        "in_progress_orders": in_progress_orders,
        "total_volume": total_volume,
        "total_profit": total_profit,
        "total_referral_payouts": total_referral_payouts,
        "top_operators": top_operators,
        "top_users": top_users
    }
