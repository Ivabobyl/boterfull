from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, MessageHandler, Filters, CallbackQueryHandler, ConversationHandler
from models import Session, User, CustomCommand
from config import UserRole, logger
from utils.keyboards import get_main_menu_keyboard
from utils.helpers import get_user_by_telegram_id, is_admin, is_operator

# States for conversation handlers
START, HELP = range(2)

def start_command(update: Update, context: CallbackContext) -> None:
    """Handle the /start command"""
    session = Session()
    try:
        # Преобразуем telegram_id в строку для совместимости с базой данных
        telegram_id_str = str(update.effective_user.id)
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        # Create user if not exists
        if not user:
            user = User(
                telegram_id=telegram_id_str,
                username=update.effective_user.username,
                first_name=update.effective_user.first_name,
                last_name=update.effective_user.last_name
            )
            session.add(user)
            session.commit()
            
            context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=f"Добро пожаловать, {user.get_full_name()}! Вы успешно зарегистрированы в системе обмена криптовалюты LTC.",
                reply_markup=get_main_menu_keyboard()
            )
        else:
            # Handle referral code if provided
            if context.args and len(context.args) > 0:
                referral_code = context.args[0]
                referrer = session.query(User).filter(User.referral_code == referral_code).first()
                
                if referrer and referrer.id != user.id and not user.referred_by:
                    user.referred_by = referrer.id
                    session.commit()
                    
                    context.bot.send_message(
                        chat_id=update.effective_chat.id,
                        text=f"Вы присоединились по реферальной ссылке от пользователя {referrer.get_full_name()}. Спасибо!"
                    )
            
            # Get the appropriate keyboard based on user role
            is_user_admin = user.role == UserRole.ADMIN
            is_user_operator = user.role == UserRole.OPERATOR or is_user_admin
            
            context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=f"С возвращением, {user.get_full_name()}! Чем я могу помочь сегодня?",
                reply_markup=get_main_menu_keyboard(is_user_operator, is_user_admin)
            )
    except Exception as e:
        logger.error(f"Error in start_command: {e}")
    finally:
        session.close()

def help_command(update: Update, context: CallbackContext) -> None:
    """Handle the /help command"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user:
            update.message.reply_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Create help message based on user role
        help_text = (
            "🤖 *Помощь по боту:*\n\n"
            "Основные команды:\n"
            "/start - Начать работу с ботом\n"
            "/help - Показать это сообщение\n"
            "/profile - Просмотр вашего профиля\n"
            "/rates - Текущие курсы\n"
            "/buy - Создать заявку на покупку LTC\n"
            "/sell - Создать заявку на продажу LTC\n"
            "/orders - Ваши заявки\n"
            "/referral - Реферальная программа\n"
            "/balance - Ваш баланс\n"
        )
        
        if is_operator(session, update.effective_user.id):
            help_text += (
                "\n*Команды оператора:*\n"
                "/active_orders - Просмотр активных заявок\n"
            )
        
        if is_admin(session, update.effective_user.id):
            help_text += (
                "\n*Команды администратора:*\n"
                "/set_rates - Установить курсы\n"
                "/users - Управление пользователями\n"
                "/broadcast - Создать рассылку\n"
                "/stats - Статистика\n"
                "/give_balance <user_id> <amount> - Выдать баланс\n"
                "/take_balance <user_id> <amount> - Изъять баланс\n"
                "/commands - Управление командами\n"
            )
        
        # Check if there are custom commands
        custom_commands = session.query(CustomCommand).filter(CustomCommand.is_active == True).all()
        if custom_commands:
            help_text += "\n*Дополнительные команды:*\n"
            for cmd in custom_commands:
                help_text += f"/{cmd.command} - Пользовательская команда\n"
        
        update.message.reply_text(
            help_text,
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Error in help_command: {e}")
    finally:
        session.close()

def handle_custom_command(update: Update, context: CallbackContext) -> None:
    """Handle custom commands created by admins"""
    session = Session()
    try:
        command_text = update.message.text[1:]  # Remove the / prefix
        command = session.query(CustomCommand).filter(
            CustomCommand.command == command_text,
            CustomCommand.is_active == True
        ).first()
        
        if command:
            update.message.reply_text(
                command.response_text,
                parse_mode="Markdown"
            )
    except Exception as e:
        logger.error(f"Error in handle_custom_command: {e}")
    finally:
        session.close()

def error_handler(update: Update, context: CallbackContext) -> None:
    """Handle errors in the bot"""
    logger.error(f"Update {update} caused error {context.error}")
    
    if update:
        update.message.reply_text(
            "Произошла ошибка при обработке вашего запроса. Пожалуйста, попробуйте еще раз позже."
        )

def get_common_handlers():
    """Return a list of common handlers"""
    return [
        CommandHandler("start", start_command),
        CommandHandler("help", help_command),
        # Error handler will be added separately in the main bot.py file
    ]
