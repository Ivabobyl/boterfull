# Initialize handlers package
from handlers.common_handlers import get_common_handlers
from handlers.user_handlers import get_user_handlers
from handlers.operator_handlers import get_operator_handlers
from handlers.admin_handlers import get_admin_handlers

def get_all_handlers():
    """Get all handlers for the bot"""
    all_handlers = []
    
    # Add common handlers
    all_handlers.extend(get_common_handlers())
    
    # Add user handlers
    all_handlers.extend(get_user_handlers())
    
    # Add operator handlers
    all_handlers.extend(get_operator_handlers())
    
    # Add admin handlers
    all_handlers.extend(get_admin_handlers())
    
    return all_handlers
