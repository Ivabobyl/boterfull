import datetime
from telegram import Update, ParseMode, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, MessageHandler, Filters, CallbackQueryHandler, ConversationHandler
from models import Session, User, Rate, CustomCommand, Order, ReferralBonus
from config import UserRole, OrderStatus, logger, DEFAULT_RATES, ADMIN_IDS
from utils.keyboards import get_admin_menu_keyboard, get_user_management_keyboard, get_pagination_keyboard, get_confirmation_keyboard, get_main_menu_keyboard
from utils.helpers import get_user_by_telegram_id, is_admin, format_currency, get_admin_stats
from sqlalchemy import func

# States for conversation handlers
SET_RATES, USER_MANAGEMENT, BROADCAST, COMMANDS, CHANGE_BALANCE = range(5)
# Sub-states for rate setting
SET_LTC_USD_BUY, SET_LTC_USD_SELL, SET_USD_RUB_BUY, SET_USD_RUB_SELL = range(5, 9)
# Sub-states for broadcasts
BROADCAST_TEXT, BROADCAST_CONFIRM = range(9, 11)
# Sub-states for custom commands
COMMAND_NAME, COMMAND_RESPONSE = range(11, 13)
# Sub-states for balance changes
BALANCE_AMOUNT = range(13, 14)

def admin_menu(update: Update, context: CallbackContext) -> None:
    """Show the admin menu"""
    session = Session()
    try:
        # Проверяем, что пользователь является администратором
        if not is_admin(session, update.effective_user.id):
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return
            
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        update.message.reply_text(
            "⚙️ *Админ-панель*\n\n"
            "Выберите действие из меню ниже:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_admin_menu_keyboard()
        )
    except Exception as e:
        logger.error(f"Error in admin_menu: {e}")
        update.message.reply_text(
            "Произошла ошибка при загрузке админ-панели. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def start_set_rates(update: Update, context: CallbackContext) -> int:
    """Start the process of setting exchange rates"""
    session = Session()
    try:
        # Проверяем, что пользователь является администратором
        if not is_admin(session, update.effective_user.id):
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return ConversationHandler.END
            
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        # Get current rates
        latest_rate = session.query(Rate).order_by(Rate.updated_at.desc()).first()
        
        if not latest_rate:
            # Create default rates if none exist
            latest_rate = Rate(
                ltc_usd_buy=DEFAULT_RATES["ltc_usd_buy"],
                ltc_usd_sell=DEFAULT_RATES["ltc_usd_sell"],
                usd_rub_buy=DEFAULT_RATES["usd_rub_buy"],
                usd_rub_sell=DEFAULT_RATES["usd_rub_sell"],
                updated_by=user.id
            )
            session.add(latest_rate)
            session.commit()
        
        # Store current rates in context
        context.user_data['rates'] = {
            "ltc_usd_buy": latest_rate.ltc_usd_buy,
            "ltc_usd_sell": latest_rate.ltc_usd_sell,
            "usd_rub_buy": latest_rate.usd_rub_buy,
            "usd_rub_sell": latest_rate.usd_rub_sell
        }
        
        update.message.reply_text(
            "📝 *Установка курсов*\n\n"
            "Текущие курсы:\n"
            f"LTC/USD (покупка): ${latest_rate.ltc_usd_buy:.2f}\n"
            f"LTC/USD (продажа): ${latest_rate.ltc_usd_sell:.2f}\n"
            f"USD/RUB (покупка): ₽{latest_rate.usd_rub_buy:.2f}\n"
            f"USD/RUB (продажа): ₽{latest_rate.usd_rub_sell:.2f}\n\n"
            "Введите новый курс покупки LTC/USD:",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return SET_LTC_USD_BUY
    except Exception as e:
        logger.error(f"Error in start_set_rates: {e}")
        update.message.reply_text(
            "Произошла ошибка при загрузке текущих курсов. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def set_ltc_usd_buy(update: Update, context: CallbackContext) -> int:
    """Set the LTC/USD buy rate"""
    try:
        rate = float(update.message.text.strip().replace(',', '.'))
        if rate <= 0:
            update.message.reply_text("Курс должен быть положительным числом. Попробуйте еще раз:")
            return SET_LTC_USD_BUY
        
        context.user_data['rates']['ltc_usd_buy'] = rate
        
        update.message.reply_text(
            f"✅ Курс покупки LTC/USD установлен: ${rate:.2f}\n\n"
            "Введите новый курс продажи LTC/USD:"
        )
        return SET_LTC_USD_SELL
    except ValueError:
        update.message.reply_text("Пожалуйста, введите корректное число:")
        return SET_LTC_USD_BUY

def set_ltc_usd_sell(update: Update, context: CallbackContext) -> int:
    """Set the LTC/USD sell rate"""
    try:
        rate = float(update.message.text.strip().replace(',', '.'))
        if rate <= 0:
            update.message.reply_text("Курс должен быть положительным числом. Попробуйте еще раз:")
            return SET_LTC_USD_SELL
        
        context.user_data['rates']['ltc_usd_sell'] = rate
        
        update.message.reply_text(
            f"✅ Курс продажи LTC/USD установлен: ${rate:.2f}\n\n"
            "Введите новый курс покупки USD/RUB:"
        )
        return SET_USD_RUB_BUY
    except ValueError:
        update.message.reply_text("Пожалуйста, введите корректное число:")
        return SET_LTC_USD_SELL

def set_usd_rub_buy(update: Update, context: CallbackContext) -> int:
    """Set the USD/RUB buy rate"""
    try:
        rate = float(update.message.text.strip().replace(',', '.'))
        if rate <= 0:
            update.message.reply_text("Курс должен быть положительным числом. Попробуйте еще раз:")
            return SET_USD_RUB_BUY
        
        context.user_data['rates']['usd_rub_buy'] = rate
        
        update.message.reply_text(
            f"✅ Курс покупки USD/RUB установлен: ₽{rate:.2f}\n\n"
            "Введите новый курс продажи USD/RUB:"
        )
        return SET_USD_RUB_SELL
    except ValueError:
        update.message.reply_text("Пожалуйста, введите корректное число:")
        return SET_USD_RUB_BUY

def set_usd_rub_sell(update: Update, context: CallbackContext) -> int:
    """Set the USD/RUB sell rate"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user or user.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return ConversationHandler.END
        
        try:
            rate = float(update.message.text.strip().replace(',', '.'))
            if rate <= 0:
                update.message.reply_text("Курс должен быть положительным числом. Попробуйте еще раз:")
                return SET_USD_RUB_SELL
            
            context.user_data['rates']['usd_rub_sell'] = rate
            
            # Create new rate record
            new_rate = Rate(
                ltc_usd_buy=context.user_data['rates']['ltc_usd_buy'],
                ltc_usd_sell=context.user_data['rates']['ltc_usd_sell'],
                usd_rub_buy=context.user_data['rates']['usd_rub_buy'],
                usd_rub_sell=context.user_data['rates']['usd_rub_sell'],
                updated_by=user.id
            )
            session.add(new_rate)
            session.commit()
            
            # Format the confirmation message
            rates_text = (
                f"✅ *Курсы успешно обновлены!*\n\n"
                f"*LTC/USD*\n"
                f"Покупка: ${new_rate.ltc_usd_buy:.2f}\n"
                f"Продажа: ${new_rate.ltc_usd_sell:.2f}\n\n"
                f"*USD/RUB*\n"
                f"Покупка: ₽{new_rate.usd_rub_buy:.2f}\n"
                f"Продажа: ₽{new_rate.usd_rub_sell:.2f}\n\n"
                f"_Обновлено: {new_rate.updated_at.strftime('%d.%m.%Y %H:%M')}_"
            )
            
            # Send the confirmation message
            update.message.reply_text(
                rates_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=get_admin_menu_keyboard()
            )
            
            return ConversationHandler.END
        except ValueError:
            update.message.reply_text("Пожалуйста, введите корректное число:")
            return SET_USD_RUB_SELL
    except Exception as e:
        logger.error(f"Error in set_usd_rub_sell: {e}")
        update.message.reply_text(
            "Произошла ошибка при обновлении курсов. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def start_user_management(update: Update, context: CallbackContext) -> int:
    """Start the user management process"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user or user.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return ConversationHandler.END
        
        update.message.reply_text(
            "👥 *Управление пользователями*\n\n"
            "Введите ID пользователя или @username для управления:",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return USER_MANAGEMENT
    except Exception as e:
        logger.error(f"Error in start_user_management: {e}")
        update.message.reply_text(
            "Произошла ошибка при загрузке управления пользователями. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def find_user(update: Update, context: CallbackContext) -> int:
    """Find a user by ID or username"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой функции."
            )
            return ConversationHandler.END
        
        search_term = update.message.text.strip()
        
        # Check if it's a Telegram ID
        if search_term.isdigit():
            user = get_user_by_telegram_id(session, int(search_term))
        # Check if it's a username (remove @ if present)
        elif search_term.startswith('@'):
            username = search_term[1:]
            user = session.query(User).filter(User.username == username).first()
        else:
            # Try to find by username without @
            user = session.query(User).filter(User.username == search_term).first()
        
        if not user:
            update.message.reply_text(
                "❌ Пользователь не найден. Пожалуйста, проверьте ID или имя пользователя и попробуйте еще раз:"
            )
            return USER_MANAGEMENT
        
        # Store user ID in context
        context.user_data['target_user_id'] = user.id
        
        # Get user statistics
        total_orders = session.query(Order).filter(Order.user_id == user.id).count()
        completed_orders = session.query(Order).filter(
            Order.user_id == user.id, 
            Order.status == OrderStatus.COMPLETED
        ).count()
        
        # Get referral info
        referral_count = user.get_referral_count(session)
        referral_earnings = session.query(func.sum(ReferralBonus.amount)).filter(
            ReferralBonus.user_id == user.id
        ).scalar() or 0
        
        # Get referred by info
        referred_by_name = "Никто"
        if user.referred_by:
            referrer = session.query(User).filter(User.id == user.referred_by).first()
            if referrer:
                referred_by_name = f"{referrer.get_full_name()} (@{referrer.username})" if referrer.username else referrer.get_full_name()
        
        # Format user info
        user_info = (
            f"👤 *Информация о пользователе*\n\n"
            f"ID: `{user.telegram_id}`\n"
            f"Имя: {user.get_full_name()}\n"
            f"Username: @{user.username or 'отсутствует'}\n"
            f"Роль: {user.role.value.capitalize()}\n"
            f"Статус: {'Активен' if user.is_active else 'Заблокирован'}\n"
            f"Баланс: {format_currency(user.balance)}\n"
            f"Дата регистрации: {user.created_at.strftime('%d.%m.%Y %H:%M')}\n\n"
            f"*Статистика:*\n"
            f"Всего заявок: {total_orders}\n"
            f"Завершенных заявок: {completed_orders}\n"
            f"Количество рефералов: {referral_count}\n"
            f"Реферальный доход: {format_currency(referral_earnings)}\n"
            f"Приглашен: {referred_by_name}\n"
            f"Реферальный код: `{user.referral_code}`\n"
        )
        
        update.message.reply_text(
            user_info,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_user_management_keyboard(user.id)
        )
        
        return ConversationHandler.END
    except Exception as e:
        logger.error(f"Error in find_user: {e}")
        update.message.reply_text(
            "Произошла ошибка при поиске пользователя. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def handle_user_management_callback(update: Update, context: CallbackContext) -> None:
    """Handle callback queries for user management"""
    query = update.callback_query
    query.answer()
    
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, query.from_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            query.edit_message_text(
                "⛔ У вас нет доступа к этой функции."
            )
            return
        
        # Extract action and user ID from callback data
        action, user_id = query.data.split("_", 1)[0], int(query.data.split("_")[-1])
        
        # Get the target user
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            query.edit_message_text(
                "❌ Пользователь не найден."
            )
            return
        
        if action == "make":
            # Get the role from callback data
            role_type = query.data.split("_")[1]
            
            if role_type == "operator":
                user.role = UserRole.OPERATOR
                action_text = "оператором"
            elif role_type == "admin":
                user.role = UserRole.ADMIN
                action_text = "администратором"
            elif role_type == "user":
                user.role = UserRole.USER
                action_text = "обычным пользователем"
            
            session.commit()
            
            # Try to notify the user
            try:
                context.bot.send_message(
                    chat_id=user.telegram_id,
                    text=f"🔔 Ваша роль изменена на: {user.role.value.capitalize()}",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending notification to user {user.telegram_id}: {e}")
            
            # Update message
            query.edit_message_text(
                f"✅ Пользователь {user.get_full_name()} (@{user.username or 'отсутствует'}) теперь {action_text}."
            )
        
        elif action == "block":
            user.is_active = False
            session.commit()
            
            # Try to notify the user
            try:
                context.bot.send_message(
                    chat_id=user.telegram_id,
                    text="🔒 Ваш аккаунт заблокирован администратором.",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending notification to user {user.telegram_id}: {e}")
            
            # Update message
            query.edit_message_text(
                f"🔒 Пользователь {user.get_full_name()} (@{user.username or 'отсутствует'}) заблокирован."
            )
        
        elif action == "unblock":
            user.is_active = True
            session.commit()
            
            # Try to notify the user
            try:
                context.bot.send_message(
                    chat_id=user.telegram_id,
                    text="🔓 Ваш аккаунт разблокирован администратором.",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending notification to user {user.telegram_id}: {e}")
            
            # Update message
            query.edit_message_text(
                f"🔓 Пользователь {user.get_full_name()} (@{user.username or 'отсутствует'}) разблокирован."
            )
        
        elif action == "change":
            # Store user ID in context for balance change
            context.user_data['target_user_id'] = user.id
            
            # Update message
            query.edit_message_text(
                f"💰 Изменение баланса для пользователя {user.get_full_name()} (@{user.username or 'отсутствует'})\n\n"
                f"Текущий баланс: {format_currency(user.balance)}\n\n"
                f"Введите сумму для изменения баланса:\n"
                f"• Положительное число для пополнения\n"
                f"• Отрицательное число для списания"
            )
            
            return BALANCE_AMOUNT
        
        elif action == "back":
            # Return to admin menu
            query.edit_message_text(
                "Возврат в меню управления пользователями."
            )
    except Exception as e:
        logger.error(f"Error in handle_user_management_callback: {e}")
        query.edit_message_text(
            "Произошла ошибка при выполнении действия. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def change_balance(update: Update, context: CallbackContext) -> int:
    """Change a user's balance"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой функции."
            )
            return ConversationHandler.END
        
        # Get the target user ID from context
        user_id = context.user_data.get('target_user_id')
        if not user_id:
            update.message.reply_text(
                "❌ Пользователь не найден."
            )
            return ConversationHandler.END
        
        # Get the user
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            update.message.reply_text(
                "❌ Пользователь не найден."
            )
            return ConversationHandler.END
        
        # Get the amount
        try:
            amount = float(update.message.text.strip().replace(',', '.'))
        except ValueError:
            update.message.reply_text(
                "❌ Пожалуйста, введите корректное число."
            )
            return BALANCE_AMOUNT
        
        # Update the balance
        old_balance = user.balance
        user.balance += amount
        
        # Make sure balance is not negative
        if user.balance < 0:
            user.balance = 0
        
        session.commit()
        
        # Format amount change
        if amount > 0:
            change_text = f"Пополнение: +{format_currency(amount)}"
        else:
            change_text = f"Списание: {format_currency(amount)}"
        
        # Try to notify the user
        try:
            context.bot.send_message(
                chat_id=user.telegram_id,
                text=(
                    f"💰 *Изменение баланса*\n\n"
                    f"{change_text}\n"
                    f"Текущий баланс: {format_currency(user.balance)}"
                ),
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            logger.error(f"Error sending notification to user {user.telegram_id}: {e}")
        
        # Send confirmation to admin
        update.message.reply_text(
            f"✅ Баланс пользователя {user.get_full_name()} (@{user.username or 'отсутствует'}) изменен:\n\n"
            f"Было: {format_currency(old_balance)}\n"
            f"{change_text}\n"
            f"Стало: {format_currency(user.balance)}",
            reply_markup=get_admin_menu_keyboard()
        )
        
        return ConversationHandler.END
    except Exception as e:
        logger.error(f"Error in change_balance: {e}")
        update.message.reply_text(
            "Произошла ошибка при изменении баланса. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def give_balance_command(update: Update, context: CallbackContext) -> None:
    """Handle the /give_balance command"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return
        
        # Check command arguments
        if len(context.args) != 2:
            update.message.reply_text(
                "❌ Неверный формат команды. Используйте: /give_balance <user_id> <amount>"
            )
            return
        
        try:
            target_telegram_id = int(context.args[0])
            amount = float(context.args[1].replace(',', '.'))
        except ValueError:
            update.message.reply_text(
                "❌ Неверный формат аргументов. ID пользователя и сумма должны быть числами."
            )
            return
        
        if amount <= 0:
            update.message.reply_text(
                "❌ Сумма должна быть положительным числом."
            )
            return
        
        # Get the target user
        user = get_user_by_telegram_id(session, target_telegram_id)
        if not user:
            update.message.reply_text(
                f"❌ Пользователь с ID {target_telegram_id} не найден."
            )
            return
        
        # Update balance
        old_balance = user.balance
        user.balance += amount
        session.commit()
        
        # Try to notify the user
        try:
            context.bot.send_message(
                chat_id=user.telegram_id,
                text=(
                    f"💰 *Изменение баланса*\n\n"
                    f"Пополнение: +{format_currency(amount)}\n"
                    f"Текущий баланс: {format_currency(user.balance)}"
                ),
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            logger.error(f"Error sending notification to user {user.telegram_id}: {e}")
        
        # Send confirmation to admin
        update.message.reply_text(
            f"✅ Баланс пользователя {user.get_full_name()} (@{user.username or 'отсутствует'}) пополнен:\n\n"
            f"Было: {format_currency(old_balance)}\n"
            f"Пополнение: +{format_currency(amount)}\n"
            f"Стало: {format_currency(user.balance)}"
        )
    except Exception as e:
        logger.error(f"Error in give_balance_command: {e}")
        update.message.reply_text(
            "Произошла ошибка при пополнении баланса. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def take_balance_command(update: Update, context: CallbackContext) -> None:
    """Handle the /take_balance command"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return
        
        # Check command arguments
        if len(context.args) != 2:
            update.message.reply_text(
                "❌ Неверный формат команды. Используйте: /take_balance <user_id> <amount>"
            )
            return
        
        try:
            target_telegram_id = int(context.args[0])
            amount = float(context.args[1].replace(',', '.'))
        except ValueError:
            update.message.reply_text(
                "❌ Неверный формат аргументов. ID пользователя и сумма должны быть числами."
            )
            return
        
        if amount <= 0:
            update.message.reply_text(
                "❌ Сумма должна быть положительным числом."
            )
            return
        
        # Get the target user
        user = get_user_by_telegram_id(session, target_telegram_id)
        if not user:
            update.message.reply_text(
                f"❌ Пользователь с ID {target_telegram_id} не найден."
            )
            return
        
        # Update balance
        old_balance = user.balance
        user.balance -= amount
        
        # Make sure balance is not negative
        if user.balance < 0:
            user.balance = 0
        
        session.commit()
        
        # Try to notify the user
        try:
            context.bot.send_message(
                chat_id=user.telegram_id,
                text=(
                    f"💰 *Изменение баланса*\n\n"
                    f"Списание: -{format_currency(amount)}\n"
                    f"Текущий баланс: {format_currency(user.balance)}"
                ),
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            logger.error(f"Error sending notification to user {user.telegram_id}: {e}")
        
        # Send confirmation to admin
        update.message.reply_text(
            f"✅ Со счета пользователя {user.get_full_name()} (@{user.username or 'отсутствует'}) списано:\n\n"
            f"Было: {format_currency(old_balance)}\n"
            f"Списание: -{format_currency(amount)}\n"
            f"Стало: {format_currency(user.balance)}"
        )
    except Exception as e:
        logger.error(f"Error in take_balance_command: {e}")
        update.message.reply_text(
            "Произошла ошибка при списании баланса. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def start_broadcast(update: Update, context: CallbackContext) -> int:
    """Start the broadcast creation process"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return ConversationHandler.END
        
        update.message.reply_text(
            "📨 *Создание рассылки*\n\n"
            "Введите текст сообщения для рассылки всем пользователям:\n"
            "(Поддерживается Markdown форматирование)",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return BROADCAST_TEXT
    except Exception as e:
        logger.error(f"Error in start_broadcast: {e}")
        update.message.reply_text(
            "Произошла ошибка при запуске создания рассылки. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def broadcast_text(update: Update, context: CallbackContext) -> int:
    """Process the broadcast text"""
    # Store the broadcast text in context
    context.user_data['broadcast_text'] = update.message.text
    
    # Show preview and confirmation
    update.message.reply_text(
        "📨 *Предпросмотр сообщения*\n\n" + update.message.text,
        parse_mode=ParseMode.MARKDOWN
    )
    
    # Ask for confirmation
    keyboard = [
        [
            InlineKeyboardButton("✅ Отправить всем", callback_data="confirm_broadcast_all"),
            InlineKeyboardButton("❌ Отмена", callback_data="cancel_broadcast")
        ],
        [
            InlineKeyboardButton("👥 Только пользователям", callback_data="confirm_broadcast_users"),
            InlineKeyboardButton("🛡️ Только операторам", callback_data="confirm_broadcast_operators")
        ],
        [
            InlineKeyboardButton("👑 Только админам", callback_data="confirm_broadcast_admins")
        ]
    ]
    
    update.message.reply_text(
        "Выберите получателей рассылки:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
    return BROADCAST_CONFIRM

def confirm_broadcast(update: Update, context: CallbackContext) -> int:
    """Send the broadcast to users"""
    query = update.callback_query
    query.answer()
    
    if query.data == "cancel_broadcast":
        query.edit_message_text(
            "❌ Создание рассылки отменено."
        )
        return ConversationHandler.END
    
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, query.from_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            query.edit_message_text(
                "⛔ У вас нет доступа к этой функции."
            )
            return ConversationHandler.END
        
        # Get the broadcast text from context
        broadcast_text = context.user_data.get('broadcast_text')
        if not broadcast_text:
            query.edit_message_text(
                "❌ Текст рассылки не найден. Пожалуйста, попробуйте еще раз."
            )
            return ConversationHandler.END
        
        # Determine target audience
        target_role = None
        if query.data == "confirm_broadcast_users":
            target_role = UserRole.USER
            role_name = "пользователям"
        elif query.data == "confirm_broadcast_operators":
            target_role = UserRole.OPERATOR
            role_name = "операторам"
        elif query.data == "confirm_broadcast_admins":
            target_role = UserRole.ADMIN
            role_name = "администраторам"
        else:  # confirm_broadcast_all
            role_name = "всем пользователям"
        
        # Query users
        if target_role:
            users = session.query(User).filter(
                User.role == target_role,
                User.is_active == True
            ).all()
        else:
            users = session.query(User).filter(
                User.is_active == True
            ).all()
        
        # Initialize counters
        total_users = len(users)
        successful = 0
        failed = 0
        
        # Update message to show progress
        progress_message = query.edit_message_text(
            f"⏳ Отправка рассылки {role_name}...\n"
            f"0/{total_users} отправлено"
        )
        
        # Send the broadcast to each user
        for i, user in enumerate(users):
            try:
                context.bot.send_message(
                    chat_id=user.telegram_id,
                    text=broadcast_text,
                    parse_mode=ParseMode.MARKDOWN
                )
                successful += 1
            except Exception as e:
                logger.error(f"Error sending broadcast to user {user.telegram_id}: {e}")
                failed += 1
            
            # Update progress every 10 users or at the end
            if (i + 1) % 10 == 0 or i + 1 == total_users:
                try:
                    progress_message.edit_text(
                        f"⏳ Отправка рассылки {role_name}...\n"
                        f"{i + 1}/{total_users} отправлено"
                    )
                except Exception as e:
                    logger.error(f"Error updating progress message: {e}")
        
        # Send final results
        query.edit_message_text(
            f"✅ *Рассылка завершена*\n\n"
            f"Целевая аудитория: {role_name}\n"
            f"Всего получателей: {total_users}\n"
            f"Успешно отправлено: {successful}\n"
            f"Не доставлено: {failed}"
        )
        
        return ConversationHandler.END
    except Exception as e:
        logger.error(f"Error in confirm_broadcast: {e}")
        query.edit_message_text(
            "Произошла ошибка при отправке рассылки. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def stats_command(update: Update, context: CallbackContext) -> None:
    """Handle the /stats command"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return
        
        # Get statistics
        stats = get_admin_stats(session)
        
        # Format top operators
        top_operators_text = ""
        for i, (username, count) in enumerate(stats['top_operators'], 1):
            top_operators_text += f"{i}. @{username or 'Unknown'}: {count} заявок\n"
        
        if not top_operators_text:
            top_operators_text = "Нет данных"
        
        # Format top users
        top_users_text = ""
        for i, (username, volume) in enumerate(stats['top_users'], 1):
            top_users_text += f"{i}. @{username or 'Unknown'}: {format_currency(volume)}\n"
        
        if not top_users_text:
            top_users_text = "Нет данных"
        
        # Create statistics message
        stats_text = (
            f"📊 *Общая статистика*\n\n"
            f"*Пользователи:*\n"
            f"Всего: {stats['total_users']}\n"
            f"Активных: {stats['active_users']}\n\n"
            f"*Заявки:*\n"
            f"Всего: {stats['total_orders']}\n"
            f"Завершенных: {stats['completed_orders']}\n"
            f"Ожидающих: {stats['pending_orders']}\n"
            f"В обработке: {stats['in_progress_orders']}\n\n"
            f"*Финансы:*\n"
            f"Общий объем: {format_currency(stats['total_volume'])}\n"
            f"Общая прибыль: {format_currency(stats['total_profit'])}\n"
            f"Выплачено рефералам: {format_currency(stats['total_referral_payouts'])}\n\n"
            f"*Топ операторов:*\n{top_operators_text}\n"
            f"*Топ пользователей по объему:*\n{top_users_text}\n"
        )
        
        update.message.reply_text(
            stats_text,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error in stats_command: {e}")
        update.message.reply_text(
            "Произошла ошибка при получении статистики. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def start_custom_commands(update: Update, context: CallbackContext) -> int:
    """Start the custom commands management process"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return ConversationHandler.END
        
        # Get current custom commands
        commands = session.query(CustomCommand).order_by(CustomCommand.command).all()
        
        if not commands:
            commands_list = "Нет настроенных команд"
        else:
            commands_list = "\n".join([f"/{cmd.command}" for cmd in commands])
        
        # Create keyboard for actions
        keyboard = [
            [InlineKeyboardButton("➕ Добавить команду", callback_data="add_command")],
            [InlineKeyboardButton("🔙 Вернуться в меню", callback_data="back_to_admin")]
        ]
        
        if commands:
            keyboard.insert(1, [InlineKeyboardButton("❌ Удалить команду", callback_data="delete_command")])
        
        update.message.reply_text(
            "🔄 *Управление командами*\n\n"
            f"Текущие команды:\n{commands_list}\n\n"
            "Выберите действие:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
        return COMMANDS
    except Exception as e:
        logger.error(f"Error in start_custom_commands: {e}")
        update.message.reply_text(
            "Произошла ошибка при загрузке управления командами. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def handle_commands_callback(update: Update, context: CallbackContext) -> int:
    """Handle command management callbacks"""
    query = update.callback_query
    query.answer()
    
    if query.data == "back_to_admin":
        query.edit_message_text(
            "Возврат в админ-меню."
        )
        return ConversationHandler.END
    
    elif query.data == "add_command":
        query.edit_message_text(
            "➕ *Добавление новой команды*\n\n"
            "Введите название команды без символа '/':",
            parse_mode=ParseMode.MARKDOWN
        )
        return COMMAND_NAME
    
    elif query.data == "delete_command":
        session = Session()
        try:
            # Get available commands
            commands = session.query(CustomCommand).order_by(CustomCommand.command).all()
            
            # Create keyboard with commands to delete
            keyboard = []
            for cmd in commands:
                keyboard.append([InlineKeyboardButton(
                    f"/{cmd.command}", 
                    callback_data=f"delete_cmd_{cmd.id}"
                )])
            
            # Add back button
            keyboard.append([InlineKeyboardButton("🔙 Назад", callback_data="back_to_commands")])
            
            query.edit_message_text(
                "❌ *Удаление команды*\n\n"
                "Выберите команду для удаления:",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
            
            return COMMANDS
        except Exception as e:
            logger.error(f"Error in handle_commands_callback (delete): {e}")
            query.edit_message_text(
                "Произошла ошибка при загрузке списка команд. Пожалуйста, попробуйте еще раз позже."
            )
            return ConversationHandler.END
        finally:
            session.close()
    
    elif query.data == "back_to_commands":
        # Return to the commands list
        return start_custom_commands(update, context)
    
    elif query.data.startswith("delete_cmd_"):
        session = Session()
        try:
            # Extract command ID
            cmd_id = int(query.data.split("_")[-1])
            
            # Get the command
            cmd = session.query(CustomCommand).filter(CustomCommand.id == cmd_id).first()
            if not cmd:
                query.edit_message_text(
                    "❌ Команда не найдена."
                )
                return ConversationHandler.END
            
            # Delete the command
            cmd_name = cmd.command
            session.delete(cmd)
            session.commit()
            
            query.edit_message_text(
                f"✅ Команда /{cmd_name} успешно удалена."
            )
            
            return ConversationHandler.END
        except Exception as e:
            logger.error(f"Error in handle_commands_callback (delete_cmd): {e}")
            query.edit_message_text(
                "Произошла ошибка при удалении команды. Пожалуйста, попробуйте еще раз позже."
            )
            return ConversationHandler.END
        finally:
            session.close()
    
    return COMMANDS

def process_command_name(update: Update, context: CallbackContext) -> int:
    """Process the custom command name"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой функции."
            )
            return ConversationHandler.END
        
        # Get the command name
        command_name = update.message.text.strip().lower()
        
        # Validate command name
        if not command_name.isalnum() and "_" not in command_name:
            update.message.reply_text(
                "❌ Название команды может содержать только буквы, цифры и подчеркивания. Попробуйте еще раз:"
            )
            return COMMAND_NAME
        
        # Check if command exists
        existing_cmd = session.query(CustomCommand).filter(CustomCommand.command == command_name).first()
        if existing_cmd:
            update.message.reply_text(
                f"❌ Команда /{command_name} уже существует. Введите другое название:"
            )
            return COMMAND_NAME
        
        # Store command name in context
        context.user_data['command_name'] = command_name
        
        update.message.reply_text(
            f"✅ Название команды: /{command_name}\n\n"
            "Теперь введите текст ответа на эту команду:\n"
            "(Поддерживается Markdown форматирование)",
            parse_mode=ParseMode.MARKDOWN
        )
        
        return COMMAND_RESPONSE
    except Exception as e:
        logger.error(f"Error in process_command_name: {e}")
        update.message.reply_text(
            "Произошла ошибка при обработке названия команды. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def process_command_response(update: Update, context: CallbackContext) -> int:
    """Process the custom command response"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой функции."
            )
            return ConversationHandler.END
        
        # Get the command name from context
        command_name = context.user_data.get('command_name')
        if not command_name:
            update.message.reply_text(
                "❌ Название команды не найдено. Пожалуйста, начните сначала."
            )
            return ConversationHandler.END
        
        # Get the response text
        response_text = update.message.text
        
        # Create the command
        cmd = CustomCommand(
            command=command_name,
            response_text=response_text,
            created_by=admin.id
        )
        session.add(cmd)
        session.commit()
        
        update.message.reply_text(
            f"✅ Команда /{command_name} успешно создана!\n\n"
            f"Ответ на команду:\n\n{response_text}",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_admin_menu_keyboard()
        )
        
        return ConversationHandler.END
    except Exception as e:
        logger.error(f"Error in process_command_response: {e}")
        update.message.reply_text(
            "Произошла ошибка при создании команды. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def users_command(update: Update, context: CallbackContext) -> None:
    """Handle the /users command to list users"""
    session = Session()
    try:
        admin = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not admin or admin.role != UserRole.ADMIN:
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return
        
        # Get page number from args or defaults to 1
        page = context.args[0] if context.args else 1
        try:
            page = int(page)
        except (ValueError, TypeError):
            page = 1
        
        # Set items per page
        items_per_page = 10
        
        # Get total number of users
        total_users = session.query(User).count()
        total_pages = (total_users + items_per_page - 1) // items_per_page
        
        # Validate page number
        if page < 1:
            page = 1
        elif page > total_pages:
            page = total_pages
        
        # Calculate offset
        offset = (page - 1) * items_per_page
        
        # Get users for current page
        users = session.query(User).order_by(User.created_at.desc()).offset(offset).limit(items_per_page).all()
        
        # Format user list
        users_text = f"👥 *Список пользователей (страница {page}/{total_pages})*\n\n"
        
        for user in users:
            role_emoji = {
                UserRole.USER: "👤",
                UserRole.OPERATOR: "🛡️",
                UserRole.ADMIN: "👑"
            }.get(user.role, "👤")
            
            status_emoji = "✅" if user.is_active else "🚫"
            
            users_text += (
                f"{role_emoji} {status_emoji} *{user.get_full_name()}*\n"
                f"ID: `{user.telegram_id}`\n"
                f"Username: @{user.username or 'отсутствует'}\n"
                f"Роль: {user.role.value.capitalize()}\n"
                f"Дата регистрации: {user.created_at.strftime('%d.%m.%Y')}\n\n"
            )
        
        # Add pagination keyboard if needed
        if total_pages > 1:
            keyboard = get_pagination_keyboard(page, total_pages, "users_page")
            update.message.reply_text(
                users_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=keyboard
            )
        else:
            update.message.reply_text(
                users_text,
                parse_mode=ParseMode.MARKDOWN
            )
    except Exception as e:
        logger.error(f"Error in users_command: {e}")
        update.message.reply_text(
            "Произошла ошибка при получении списка пользователей. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def handle_users_pagination(update: Update, context: CallbackContext) -> None:
    """Handle pagination for users list"""
    query = update.callback_query
    query.answer()
    
    # Extract page number from callback data
    page = int(query.data.split("_")[-1])
    
    # Call users_command with the specified page
    context.args = [page]
    users_command(update, context)

def get_admin_handlers():
    """Return a list of admin handlers"""
    return [
        MessageHandler(Filters.regex(r"^⚙️ Админ-панель$"), admin_menu),
        CommandHandler("stats", stats_command),
        CommandHandler("users", users_command),
        CallbackQueryHandler(handle_users_pagination, pattern=r"^users_page_\d+$"),
        CommandHandler("give_balance", give_balance_command),
        CommandHandler("take_balance", take_balance_command),
        CallbackQueryHandler(handle_user_management_callback, pattern=r"^(make|block|unblock|change|back)_"),
        ConversationHandler(
            entry_points=[
                CommandHandler("set_rates", start_set_rates),
                MessageHandler(Filters.regex(r"^📝 Установить курсы$"), start_set_rates)
            ],
            states={
                SET_LTC_USD_BUY: [MessageHandler(Filters.text & ~Filters.command, set_ltc_usd_buy)],
                SET_LTC_USD_SELL: [MessageHandler(Filters.text & ~Filters.command, set_ltc_usd_sell)],
                SET_USD_RUB_BUY: [MessageHandler(Filters.text & ~Filters.command, set_usd_rub_buy)],
                SET_USD_RUB_SELL: [MessageHandler(Filters.text & ~Filters.command, set_usd_rub_sell)]
            },
            fallbacks=[CommandHandler("cancel", lambda u, c: ConversationHandler.END)]
        ),
        ConversationHandler(
            entry_points=[
                CommandHandler("broadcast", start_broadcast),
                MessageHandler(Filters.regex(r"^📨 Создать рассылку$"), start_broadcast)
            ],
            states={
                BROADCAST_TEXT: [MessageHandler(Filters.text & ~Filters.command, broadcast_text)],
                BROADCAST_CONFIRM: [CallbackQueryHandler(confirm_broadcast, pattern=r"^(confirm|cancel)_broadcast")]
            },
            fallbacks=[CommandHandler("cancel", lambda u, c: ConversationHandler.END)]
        ),
        ConversationHandler(
            entry_points=[
                CommandHandler("commands", start_custom_commands),
                MessageHandler(Filters.regex(r"^🔄 Управление командами$"), start_custom_commands)
            ],
            states={
                COMMANDS: [CallbackQueryHandler(handle_commands_callback)],
                COMMAND_NAME: [MessageHandler(Filters.text & ~Filters.command, process_command_name)],
                COMMAND_RESPONSE: [MessageHandler(Filters.text & ~Filters.command, process_command_response)]
            },
            fallbacks=[CommandHandler("cancel", lambda u, c: ConversationHandler.END)]
        ),
        ConversationHandler(
            entry_points=[
                CommandHandler("users", users_command),
                MessageHandler(Filters.regex(r"^👥 Управление пользователями$"), start_user_management)
            ],
            states={
                USER_MANAGEMENT: [MessageHandler(Filters.text & ~Filters.command, find_user)],
                BALANCE_AMOUNT: [MessageHandler(Filters.text & ~Filters.command, change_balance)]
            },
            fallbacks=[CommandHandler("cancel", lambda u, c: ConversationHandler.END)]
        )
    ]
