from telegram import Update, ParseMode, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, MessageHandler, Filters, CallbackQueryHandler, ConversationHandler
from models import Session, User, Order, Rate
from config import UserRole, OrderType, OrderStatus, logger
from utils.keyboards import (
    get_main_menu_keyboard, get_back_keyboard, get_order_action_keyboard,
    get_pagination_keyboard, get_referral_keyboard
)
from utils.helpers import (
    get_user_by_telegram_id, get_current_rates, calculate_ltc_amount,
    format_currency, get_user_stats, generate_order_summary
)
from services.rates_service import get_current_rates as get_rates_from_service

# States for conversation handlers
AMOUNT, CONFIRMATION = range(2)

def profile_command(update: Update, context: CallbackContext) -> None:
    """Handle the /profile command"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user:
            update.message.reply_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Get user statistics
        stats = get_user_stats(session, user.id)
        
        profile_text = (
            f"👤 *Профиль пользователя*\n\n"
            f"Имя: {user.get_full_name()}\n"
            f"ID: `{user.telegram_id}`\n"
            f"Роль: {user.role.value.capitalize()}\n"
            f"Баланс: {format_currency(user.balance)}\n\n"
            f"📊 *Статистика*\n"
            f"Всего заявок: {stats['total_orders']}\n"
            f"Завершенных заявок: {stats['completed_orders']}\n"
            f"Активных заявок: {stats['pending_orders']}\n"
            f"Общий оборот: {format_currency(stats['total_volume'])}\n\n"
            f"👥 *Реферальная программа*\n"
            f"Ваш реферальный код: `{user.referral_code}`\n"
            f"Количество рефералов: {stats['referral_count']}\n"
            f"Текущий процент вознаграждения: {stats['current_referral_percentage']:.1f}%\n"
            f"Всего заработано: {format_currency(stats['total_referral_earnings'])}\n"
        )
        
        update.message.reply_text(
            profile_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_main_menu_keyboard(
                user.role == UserRole.OPERATOR or user.role == UserRole.ADMIN,
                user.role == UserRole.ADMIN
            )
        )
    except Exception as e:
        logger.error(f"Error in profile_command: {e}")
    finally:
        session.close()

def rates_command(update: Update, context: CallbackContext) -> None:
    """Handle the /rates command"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user:
            update.message.reply_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Get current rates
        rates = get_current_rates(session)
        
        rates_text = (
            f"📊 *Текущие курсы*\n\n"
            f"*LTC/USD*\n"
            f"Покупка: ${rates['ltc_usd_buy']:.2f}\n"
            f"Продажа: ${rates['ltc_usd_sell']:.2f}\n\n"
            f"*USD/RUB*\n"
            f"Покупка: ₽{rates['usd_rub_buy']:.2f}\n"
            f"Продажа: ₽{rates['usd_rub_sell']:.2f}\n\n"
            f"_Курсы обновлены: {rates.get('updated_at', 'Недавно')}_"
        )
        
        update.message.reply_text(
            rates_text,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error in rates_command: {e}")
    finally:
        session.close()

def start_buy(update: Update, context: CallbackContext) -> int:
    """Start the buy order process"""
    # Проверяем наличие установленных курсов обмена (установленных админом)
    rates = get_rates_from_service()
    if not rates:
        update.message.reply_text(
            "❌ *Обмен временно недоступен*\n\n"
            "Администратор еще не установил курсы обмена. "
            "Пожалуйста, попробуйте позже.",
            parse_mode=ParseMode.MARKDOWN
        )
        return ConversationHandler.END
        
    update.message.reply_text(
        "💵 *Создание заявки на покупку LTC*\n\n"
        "Пожалуйста, введите сумму в рублях:",
        parse_mode=ParseMode.MARKDOWN
    )
    context.user_data['order_type'] = 'buy'
    return AMOUNT

def start_sell(update: Update, context: CallbackContext) -> int:
    """Start the sell order process"""
    # Проверяем наличие установленных курсов обмена (установленных админом)
    rates = get_rates_from_service()
    if not rates:
        update.message.reply_text(
            "❌ *Обмен временно недоступен*\n\n"
            "Администратор еще не установил курсы обмена. "
            "Пожалуйста, попробуйте позже.",
            parse_mode=ParseMode.MARKDOWN
        )
        return ConversationHandler.END
        
    update.message.reply_text(
        "💰 *Создание заявки на продажу LTC*\n\n"
        "Пожалуйста, введите сумму в рублях:",
        parse_mode=ParseMode.MARKDOWN
    )
    context.user_data['order_type'] = 'sell'
    return AMOUNT

def process_amount(update: Update, context: CallbackContext) -> int:
    """Process the amount entered by the user"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user:
            update.message.reply_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return ConversationHandler.END
        
        # Get the amount from the user's message
        try:
            amount = float(update.message.text.strip().replace(',', '.'))
        except ValueError:
            update.message.reply_text(
                "❌ Пожалуйста, введите корректную сумму (только числа)."
            )
            return AMOUNT
        
        # Check minimum amount
        if amount < 1000:
            update.message.reply_text(
                "❌ Минимальная сумма для обмена: 1000 рублей."
            )
            return AMOUNT
        
        # Store amount in context
        context.user_data['amount'] = amount
        
        # Calculate LTC amount based on current rates
        order_type = context.user_data['order_type']
        ltc_amount = calculate_ltc_amount(session, amount, order_type)
        context.user_data['ltc_amount'] = ltc_amount
        
        # Get current rates
        rates = get_current_rates(session)
        
        # Create confirmation message
        action = "покупку" if order_type == 'buy' else "продажу"
        confirmation_text = (
            f"📝 *Подтверждение заявки на {action} LTC*\n\n"
            f"Сумма: {format_currency(amount)}\n"
            f"Количество LTC: {format_currency(ltc_amount, 'LTC')}\n\n"
            f"*Текущие курсы:*\n"
            f"LTC/USD: ${rates['ltc_usd_buy' if order_type == 'buy' else 'ltc_usd_sell']:.2f}\n"
            f"USD/RUB: ₽{rates['usd_rub_buy' if order_type == 'buy' else 'usd_rub_sell']:.2f}\n\n"
            f"Пожалуйста, подтвердите создание заявки:"
        )
        
        keyboard = [
            [
                InlineKeyboardButton("✅ Подтвердить", callback_data="confirm_order"),
                InlineKeyboardButton("❌ Отменить", callback_data="cancel_order")
            ]
        ]
        
        update.message.reply_text(
            confirmation_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        
        return CONFIRMATION
    except Exception as e:
        logger.error(f"Error in process_amount: {e}")
        update.message.reply_text(
            "Произошла ошибка при обработке вашего запроса. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def confirm_order(update: Update, context: CallbackContext) -> int:
    """Confirm and create the order"""
    query = update.callback_query
    query.answer()
    
    if query.data == "cancel_order":
        query.edit_message_text(
            "❌ Создание заявки отменено."
        )
        return ConversationHandler.END
    
    session = Session()
    try:
        user = get_user_by_telegram_id(session, query.from_user.id)
        
        if not user:
            query.edit_message_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return ConversationHandler.END
        
        # Get data from context
        amount = context.user_data.get('amount')
        ltc_amount = context.user_data.get('ltc_amount')
        order_type = context.user_data.get('order_type')
        
        if not all([amount, ltc_amount, order_type]):
            query.edit_message_text(
                "❌ Произошла ошибка при создании заявки. Пожалуйста, попробуйте еще раз."
            )
            return ConversationHandler.END
        
        # Get current rates
        rates = get_current_rates(session)
        
        # Create the order
        order = Order(
            user_id=user.id,
            type=OrderType.BUY if order_type == 'buy' else OrderType.SELL,
            amount_rub=amount,
            amount_ltc=ltc_amount,
            rate_ltc_usd=rates['ltc_usd_buy' if order_type == 'buy' else 'ltc_usd_sell'],
            rate_usd_rub=rates['usd_rub_buy' if order_type == 'buy' else 'usd_rub_sell']
        )
        
        session.add(order)
        session.commit()
        
        # Send notification to operators and admins
        action = "покупку" if order_type == 'buy' else "продажу"
        notification_text = (
            f"🔔 *Новая заявка #{order.order_number}*\n\n"
            f"Пользователь: {user.get_full_name()} (@{user.username})\n"
            f"Тип: {action} LTC\n"
            f"Сумма: {format_currency(amount)}\n"
            f"Количество LTC: {format_currency(ltc_amount, 'LTC')}"
        )
        
        # Отправка уведомления в общий чат операторов
        try:
            from config import NOTIFICATION_CHAT_ID
            from utils.keyboards import get_new_order_keyboard
            
            if NOTIFICATION_CHAT_ID:
                context.bot.send_message(
                    chat_id=NOTIFICATION_CHAT_ID,
                    text=notification_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=get_new_order_keyboard(order.id)
                )
                logger.info(f"Notification sent to operator chat: {NOTIFICATION_CHAT_ID}")
        except Exception as e:
            logger.error(f"Failed to send notification to operator chat: {e}")
        
        # Get operators and admins for individual notifications
        operators = session.query(User).filter(
            (User.role == UserRole.OPERATOR) | (User.role == UserRole.ADMIN),
            User.is_active == True
        ).all()
        
        for operator in operators:
            try:
                context.bot.send_message(
                    chat_id=operator.telegram_id,
                    text=notification_text,
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=get_order_action_keyboard(order.id, True, operator.role == UserRole.ADMIN)
                )
            except Exception as e:
                logger.error(f"Error sending notification to operator {operator.telegram_id}: {e}")
        
        # Confirm to user
        query.edit_message_text(
            f"✅ Заявка #{order.order_number} на {action} LTC успешно создана!\n\n"
            f"Сумма: {format_currency(amount)}\n"
            f"Количество LTC: {format_currency(ltc_amount, 'LTC')}\n\n"
            f"Оператор свяжется с вами в ближайшее время для обработки заявки."
        )
        
        return ConversationHandler.END
    except Exception as e:
        logger.error(f"Error in confirm_order: {e}")
        query.edit_message_text(
            "Произошла ошибка при создании заявки. Пожалуйста, попробуйте еще раз позже."
        )
        return ConversationHandler.END
    finally:
        session.close()

def orders_command(update: Update, context: CallbackContext) -> None:
    """Handle the /orders command"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user:
            update.message.reply_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Get user's orders
        orders = session.query(Order).filter(Order.user_id == user.id).order_by(Order.created_at.desc()).all()
        
        if not orders:
            update.message.reply_text(
                "У вас пока нет заявок. Используйте команды /buy или /sell для создания новой заявки."
            )
            return
        
        # Display orders with pagination (5 per page)
        page = context.args[0] if context.args else 1
        try:
            page = int(page)
        except (ValueError, TypeError):
            page = 1
        
        items_per_page = 5
        total_pages = (len(orders) + items_per_page - 1) // items_per_page
        
        # Make sure page is within valid range
        if page < 1:
            page = 1
        elif page > total_pages:
            page = total_pages
        
        # Get orders for the current page
        start_idx = (page - 1) * items_per_page
        end_idx = min(start_idx + items_per_page, len(orders))
        current_orders = orders[start_idx:end_idx]
        
        # Generate the message
        orders_text = f"📚 *Ваши заявки (страница {page}/{total_pages})*\n\n"
        
        for order in current_orders:
            status_emoji = {
                OrderStatus.PENDING: "⏳",
                OrderStatus.IN_PROGRESS: "🔄",
                OrderStatus.COMPLETED: "✅",
                OrderStatus.CANCELLED: "❌"
            }.get(order.status, "⏳")
            
            order_type = "Покупка" if order.type == OrderType.BUY else "Продажа"
            
            orders_text += (
                f"{status_emoji} *Заявка #{order.order_number}*\n"
                f"Тип: {order_type} LTC\n"
                f"Сумма: {format_currency(order.amount_rub)}\n"
                f"Количество LTC: {format_currency(order.amount_ltc, 'LTC')}\n"
                f"Статус: {order.status.value}\n"
                f"Дата: {order.created_at.strftime('%d.%m.%Y %H:%M')}\n\n"
            )
        
        # Add pagination keyboard if needed
        if total_pages > 1:
            pagination_keyboard = get_pagination_keyboard(page, total_pages, "orders_page")
            update.message.reply_text(
                orders_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=pagination_keyboard
            )
        else:
            update.message.reply_text(
                orders_text,
                parse_mode=ParseMode.MARKDOWN
            )
    except Exception as e:
        logger.error(f"Error in orders_command: {e}")
        update.message.reply_text(
            "Произошла ошибка при получении ваших заявок. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def handle_orders_pagination(update: Update, context: CallbackContext) -> None:
    """Handle pagination for orders"""
    query = update.callback_query
    query.answer()
    
    # Extract page number from callback data
    page = int(query.data.split("_")[-1])
    
    # Call orders_command with the specified page
    context.args = [page]
    orders_command(update, context)

def balance_command(update: Update, context: CallbackContext) -> None:
    """Handle the /balance command"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user:
            update.message.reply_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Display balance
        balance_text = (
            f"💰 *Ваш баланс*\n\n"
            f"Текущий баланс: {format_currency(user.balance)}\n\n"
        )
        
        # Show referral information
        referral_earnings = session.query(ReferralBonus).filter(ReferralBonus.user_id == user.id).all()
        if referral_earnings:
            recent_earnings = referral_earnings[-5:] if len(referral_earnings) > 5 else referral_earnings
            
            balance_text += "📈 *Недавние реферальные начисления:*\n"
            for earning in recent_earnings:
                referral = session.query(User).filter(User.id == earning.referral_id).first()
                referral_name = referral.get_full_name() if referral else "Unknown"
                
                balance_text += (
                    f"• {format_currency(earning.amount)} ({earning.percentage * 100:.1f}%) от "
                    f"{referral_name} - {earning.created_at.strftime('%d.%m.%Y')}\n"
                )
        
        update.message.reply_text(
            balance_text,
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Error in balance_command: {e}")
        update.message.reply_text(
            "Произошла ошибка при получении информации о балансе. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def referral_command(update: Update, context: CallbackContext) -> None:
    """Handle the /referral command"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user:
            update.message.reply_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Get statistics
        stats = get_user_stats(session, user.id)
        
        # Create referral link
        bot_username = context.bot.username
        referral_link = f"https://t.me/{bot_username}?start={user.referral_code}"
        
        referral_text = (
            f"👥 *Реферальная программа*\n\n"
            f"Приглашайте друзей и получайте процент от спреда обменника!\n\n"
            f"Ваш реферальный код: `{user.referral_code}`\n"
            f"Ваша реферальная ссылка:\n"
            f"`{referral_link}`\n\n"
            f"*Условия программы:*\n"
            f"• 1-10 рефералов: 10% от спреда\n"
            f"• 10-25 рефералов: 12.5% от спреда\n"
            f"• 25-50 рефералов: 15% от спреда\n"
            f"• 50-100 рефералов: 17.5% от спреда\n"
            f"• 100+ рефералов: 20% от спреда\n\n"
            f"*Ваша статистика:*\n"
            f"Количество рефералов: {stats['referral_count']}\n"
            f"Текущий процент вознаграждения: {stats['current_referral_percentage']:.1f}%\n"
            f"Всего заработано: {format_currency(stats['total_referral_earnings'])}\n"
        )
        
        update.message.reply_text(
            referral_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=get_referral_keyboard(user.referral_code)
        )
    except Exception as e:
        logger.error(f"Error in referral_command: {e}")
        update.message.reply_text(
            "Произошла ошибка при получении информации о реферальной программе. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def get_user_handlers():
    """Return a list of user handlers"""
    return [
        CommandHandler("profile", profile_command),
        CommandHandler("rates", rates_command),
        CommandHandler("balance", balance_command),
        CommandHandler("referral", referral_command),
        CommandHandler("orders", orders_command),
        CallbackQueryHandler(handle_orders_pagination, pattern=r"^orders_page_\d+$"),
        ConversationHandler(
            entry_points=[
                CommandHandler("buy", start_buy),
                MessageHandler(Filters.regex(r"^💵 Купить LTC$"), start_buy),
                CommandHandler("sell", start_sell),
                MessageHandler(Filters.regex(r"^💰 Продать LTC$"), start_sell)
            ],
            states={
                AMOUNT: [MessageHandler(Filters.text & ~Filters.command, process_amount)],
                CONFIRMATION: [CallbackQueryHandler(confirm_order, pattern=r"^(confirm|cancel)_order$")]
            },
            fallbacks=[CommandHandler("cancel", lambda u, c: ConversationHandler.END)]
        )
    ]
