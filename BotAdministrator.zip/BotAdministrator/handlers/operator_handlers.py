from telegram import Update, ParseMode, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, MessageHandler, Filters, CallbackQueryHandler
from models import Session, User, Order
from config import UserRole, OrderStatus, NOTIFICATION_CHAT_ID, logger
from utils.keyboards import get_order_action_keyboard, get_pagination_keyboard
from utils.helpers import (
    get_user_by_telegram_id, is_operator, is_admin,
    calculate_spread, process_referral_bonus, generate_order_summary,
    format_currency
)

def active_orders_command(update: Update, context: CallbackContext) -> None:
    """Handle the /active_orders command"""
    session = Session()
    try:
        user = get_user_by_telegram_id(session, update.effective_user.id)
        
        if not user:
            update.message.reply_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Check if user is an operator or admin
        if not is_operator(session, update.effective_user.id):
            update.message.reply_text(
                "⛔ У вас нет доступа к этой команде."
            )
            return
        
        # Get active orders (pending and in progress)
        active_orders = session.query(Order).filter(
            Order.status.in_([OrderStatus.PENDING, OrderStatus.IN_PROGRESS])
        ).order_by(Order.created_at.asc()).all()
        
        if not active_orders:
            update.message.reply_text(
                "На данный момент нет активных заявок."
            )
            return
        
        # Display orders with pagination (5 per page)
        page = context.args[0] if context.args else 1
        try:
            page = int(page)
        except (ValueError, TypeError):
            page = 1
        
        items_per_page = 5
        total_pages = (len(active_orders) + items_per_page - 1) // items_per_page
        
        # Make sure page is within valid range
        if page < 1:
            page = 1
        elif page > total_pages:
            page = total_pages
        
        # Get orders for the current page
        start_idx = (page - 1) * items_per_page
        end_idx = min(start_idx + items_per_page, len(active_orders))
        current_orders = active_orders[start_idx:end_idx]
        
        # Generate the message
        orders_text = f"📋 *Активные заявки (страница {page}/{total_pages})*\n\n"
        
        for order in current_orders:
            # Get user info
            order_user = session.query(User).filter(User.id == order.user_id).first()
            user_name = order_user.get_full_name() if order_user else "Unknown"
            
            status_text = "⏳ Ожидает" if order.status == OrderStatus.PENDING else "🔄 В работе"
            operator_text = ""
            
            # If order is in progress, show the operator
            if order.status == OrderStatus.IN_PROGRESS and order.operator_id:
                operator = session.query(User).filter(User.id == order.operator_id).first()
                if operator:
                    operator_text = f"Оператор: {operator.get_full_name()}\n"
            
            order_type = "Покупка" if order.type.value == "buy" else "Продажа"
            
            orders_text += (
                f"*Заявка #{order.order_number}* ({status_text})\n"
                f"Пользователь: {user_name} (@{order_user.username if order_user.username else 'none'})\n"
                f"{operator_text}"
                f"Тип: {order_type} LTC\n"
                f"Сумма: {format_currency(order.amount_rub)}\n"
                f"Количество LTC: {format_currency(order.amount_ltc, 'LTC')}\n"
                f"Создана: {order.created_at.strftime('%d.%m.%Y %H:%M')}\n"
            )
            
            # Show spread to operators
            if is_operator(session, update.effective_user.id):
                potential_spread = calculate_spread(session, order.id)
                orders_text += f"Спред: {format_currency(potential_spread)}\n"
            
            orders_text += "\n"
        
        # Show pagination keyboard if needed
        if total_pages > 1:
            pagination_keyboard = get_pagination_keyboard(page, total_pages, "active_orders_page")
            update.message.reply_text(
                orders_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=pagination_keyboard
            )
        else:
            update.message.reply_text(
                orders_text,
                parse_mode=ParseMode.MARKDOWN
            )
    except Exception as e:
        logger.error(f"Error in active_orders_command: {e}")
        update.message.reply_text(
            "Произошла ошибка при получении активных заявок. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def handle_active_orders_pagination(update: Update, context: CallbackContext) -> None:
    """Handle pagination for active orders"""
    query = update.callback_query
    query.answer()
    
    # Extract page number from callback data
    page = int(query.data.split("_")[-1])
    
    # Call active_orders_command with the specified page
    context.args = [page]
    active_orders_command(update, context)

def take_order(update: Update, context: CallbackContext) -> None:
    """Handle taking an order by an operator"""
    query = update.callback_query
    query.answer()
    
    session = Session()
    try:
        user = get_user_by_telegram_id(session, query.from_user.id)
        
        if not user:
            query.edit_message_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Check if user is an operator or admin
        if not is_operator(session, query.from_user.id):
            query.edit_message_text(
                "⛔ У вас нет доступа к этой функции."
            )
            return
        
        # Extract order ID from callback data
        order_id = int(query.data.split("_")[-1])
        
        # Get the order
        order = session.query(Order).filter(Order.id == order_id).first()
        if not order:
            query.edit_message_text(
                "❌ Заявка не найдена."
            )
            return
        
        # Check if order is already in progress
        if order.status == OrderStatus.IN_PROGRESS:
            operator = session.query(User).filter(User.id == order.operator_id).first()
            operator_name = operator.get_full_name() if operator else "другой оператор"
            
            query.edit_message_text(
                f"❌ Заявка #{order.order_number} уже обрабатывается оператором {operator_name}."
            )
            return
        
        # Check if order is completed or cancelled
        if order.status in [OrderStatus.COMPLETED, OrderStatus.CANCELLED]:
            query.edit_message_text(
                f"❌ Заявка #{order.order_number} уже завершена или отменена."
            )
            return
        
        # Update order status and assign operator
        order.status = OrderStatus.IN_PROGRESS
        order.operator_id = user.id
        
        # Рассчитываем спред (комиссию) для заявки
        spread = calculate_spread(session, order.id)
        order.spread = spread
        session.commit()
        
        # Notify the user
        order_user = session.query(User).filter(User.id == order.user_id).first()
        if order_user:
            try:
                context.bot.send_message(
                    chat_id=order_user.telegram_id,
                    text=(
                        f"🔔 *Обновление по заявке #{order.order_number}*\n\n"
                        f"Оператор @{user.username if user.username else user.get_full_name()} "
                        f"начал обработку вашей заявки.\n"
                        f"Пожалуйста, ожидайте дальнейших инструкций."
                    ),
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending notification to user {order_user.telegram_id}: {e}")
        
        # Update message
        query.edit_message_text(
            f"✅ Вы взяли заявку #{order.order_number} в работу.\n\n"
            f"Спред (комиссия): {format_currency(spread)}\n"
            f"Пожалуйста, свяжитесь с пользователем для уточнения деталей."
        )
        
        # Send notification to NOTIFICATION_CHAT_ID if it exists
        if NOTIFICATION_CHAT_ID:
            try:
                context.bot.send_message(
                    chat_id=NOTIFICATION_CHAT_ID,
                    text=(
                        f"🔄 *Заявка #{order.order_number} взята в работу*\n\n"
                        f"Оператор: {user.get_full_name()} (@{user.username if user.username else 'none'})\n"
                        f"Спред (комиссия): {format_currency(spread)}\n"
                        f"Пользователь: {order_user.get_full_name() if order_user else 'Unknown'} "
                        f"(@{order_user.username if order_user and order_user.username else 'none'})"
                    ),
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("✅ Завершить", callback_data=f"complete_order_{order.id}")
                    ]])
                )
            except Exception as e:
                logger.error(f"Error sending notification to chat {NOTIFICATION_CHAT_ID}: {e}")
    except Exception as e:
        logger.error(f"Error in take_order: {e}")
        query.edit_message_text(
            "Произошла ошибка при обработке заявки. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def complete_order(update: Update, context: CallbackContext) -> None:
    """Handle completing an order by an operator"""
    query = update.callback_query
    query.answer()
    
    session = Session()
    try:
        user = get_user_by_telegram_id(session, query.from_user.id)
        
        if not user:
            query.edit_message_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Check if user is an operator or admin
        if not is_operator(session, query.from_user.id):
            query.edit_message_text(
                "⛔ У вас нет доступа к этой функции."
            )
            return
        
        # Extract order ID from callback data
        order_id = int(query.data.split("_")[-1])
        
        # Get the order
        order = session.query(Order).filter(Order.id == order_id).first()
        if not order:
            query.edit_message_text(
                "❌ Заявка не найдена."
            )
            return
        
        # Check if order is already completed or cancelled
        if order.status in [OrderStatus.COMPLETED, OrderStatus.CANCELLED]:
            query.edit_message_text(
                f"❌ Заявка #{order.order_number} уже завершена или отменена."
            )
            return
        
        # Check if user is the assigned operator or an admin
        if order.operator_id != user.id and not is_admin(session, query.from_user.id):
            query.edit_message_text(
                f"❌ Заявка #{order.order_number} назначена другому оператору."
            )
            return
        
        # Update order status, set completed_at timestamp
        order.status = OrderStatus.COMPLETED
        order.completed_at = datetime.datetime.utcnow()
        
        # Calculate and save spread
        order.spread = calculate_spread(session, order.id)
        
        session.commit()
        
        # Process referral bonus if applicable
        process_referral_bonus(session, order.id)
        
        # Generate order summary
        summary = generate_order_summary(session, order.id)
        
        # Notify the user
        order_user = session.query(User).filter(User.id == order.user_id).first()
        if order_user:
            try:
                context.bot.send_message(
                    chat_id=order_user.telegram_id,
                    text=(
                        f"✅ *Заявка #{order.order_number} успешно завершена!*\n\n"
                        f"Спасибо за использование нашего сервиса!\n"
                        f"Детали заявки:\n"
                        f"- Тип: {'Покупка' if order.type.value == 'buy' else 'Продажа'} LTC\n"
                        f"- Сумма: {format_currency(order.amount_rub)}\n"
                        f"- Количество LTC: {format_currency(order.amount_ltc, 'LTC')}"
                    ),
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending notification to user {order_user.telegram_id}: {e}")
        
        # Update message
        query.edit_message_text(
            f"✅ Заявка #{order.order_number} успешно завершена."
        )
        
        # Send notification to NOTIFICATION_CHAT_ID if it exists
        if NOTIFICATION_CHAT_ID:
            try:
                context.bot.send_message(
                    chat_id=NOTIFICATION_CHAT_ID,
                    text=summary,
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending notification to chat {NOTIFICATION_CHAT_ID}: {e}")
    except Exception as e:
        logger.error(f"Error in complete_order: {e}")
        query.edit_message_text(
            "Произошла ошибка при завершении заявки. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def cancel_order(update: Update, context: CallbackContext) -> None:
    """Handle cancelling an order"""
    query = update.callback_query
    query.answer()
    
    session = Session()
    try:
        user = get_user_by_telegram_id(session, query.from_user.id)
        
        if not user:
            query.edit_message_text(
                "Пожалуйста, используйте команду /start для начала работы с ботом."
            )
            return
        
        # Extract order ID from callback data
        order_id = int(query.data.split("_")[-1])
        
        # Get the order
        order = session.query(Order).filter(Order.id == order_id).first()
        if not order:
            query.edit_message_text(
                "❌ Заявка не найдена."
            )
            return
        
        # Check if order is already completed or cancelled
        if order.status in [OrderStatus.COMPLETED, OrderStatus.CANCELLED]:
            query.edit_message_text(
                f"❌ Заявка #{order.order_number} уже завершена или отменена."
            )
            return
        
        # Check if user is the owner of the order, the assigned operator, or an admin
        if order.user_id != user.id and order.operator_id != user.id and not is_admin(session, query.from_user.id):
            query.edit_message_text(
                f"❌ У вас нет доступа к отмене этой заявки."
            )
            return
        
        # Update order status
        order.status = OrderStatus.CANCELLED
        session.commit()
        
        # Notify the user if cancelled by operator
        if order.user_id != user.id:
            order_user = session.query(User).filter(User.id == order.user_id).first()
            if order_user:
                try:
                    context.bot.send_message(
                        chat_id=order_user.telegram_id,
                        text=(
                            f"❌ *Заявка #{order.order_number} отменена*\n\n"
                            f"Ваша заявка была отменена оператором.\n"
                            f"Для создания новой заявки используйте команды /buy или /sell."
                        ),
                        parse_mode=ParseMode.MARKDOWN
                    )
                except Exception as e:
                    logger.error(f"Error sending notification to user {order_user.telegram_id}: {e}")
        
        # Notify the operator if cancelled by user
        if order.operator_id and order.operator_id != user.id:
            operator = session.query(User).filter(User.id == order.operator_id).first()
            if operator:
                try:
                    context.bot.send_message(
                        chat_id=operator.telegram_id,
                        text=(
                            f"❌ *Заявка #{order.order_number} отменена*\n\n"
                            f"Заявка была отменена пользователем."
                        ),
                        parse_mode=ParseMode.MARKDOWN
                    )
                except Exception as e:
                    logger.error(f"Error sending notification to operator {operator.telegram_id}: {e}")
        
        # Update message
        query.edit_message_text(
            f"❌ Заявка #{order.order_number} отменена."
        )
        
        # Send notification to NOTIFICATION_CHAT_ID if it exists
        if NOTIFICATION_CHAT_ID:
            try:
                context.bot.send_message(
                    chat_id=NOTIFICATION_CHAT_ID,
                    text=(
                        f"❌ *Заявка #{order.order_number} отменена*\n\n"
                        f"Отменивший: {user.get_full_name()} (@{user.username if user.username else 'none'})"
                    ),
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                logger.error(f"Error sending notification to chat {NOTIFICATION_CHAT_ID}: {e}")
    except Exception as e:
        logger.error(f"Error in cancel_order: {e}")
        query.edit_message_text(
            "Произошла ошибка при отмене заявки. Пожалуйста, попробуйте еще раз позже."
        )
    finally:
        session.close()

def get_operator_handlers():
    """Return a list of operator handlers"""
    return [
        CommandHandler("active_orders", active_orders_command),
        CallbackQueryHandler(handle_active_orders_pagination, pattern=r"^active_orders_page_\d+$"),
        CallbackQueryHandler(take_order, pattern=r"^take_order_\d+$"),
        CallbackQueryHandler(complete_order, pattern=r"^complete_order_\d+$"),
        CallbackQueryHandler(cancel_order, pattern=r"^cancel_order_\d+$")
    ]
